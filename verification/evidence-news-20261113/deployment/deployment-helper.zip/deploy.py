"""Task-only release with readonly accounting and guarded old-topic rejection checks."""
from contextlib import closing
from datetime import datetime,timezone
from pathlib import Path
import hashlib
import json
import sqlite3
import subprocess
import sys

W=Path('D:/code/_codex_worktrees/ai-schedule-stability/stock_ai_bot')
P=Path('D:/code/stock_ai_bot')
OUT=W/'verification/evidence-news-20261113/deployment'
OUT.mkdir(parents=True,exist_ok=True)
BASE='e41cf50d7675b6aa592b709bab0785715397beb7'
SOURCE=['main.py','prompt/news/news_summary.md','research_center/deepseek_search_service.py',
        'research_center/entity_resolver.py','research_center/news_service.py','research_center/topic_citation_audit.py',
        'research_center/topic_input_package.py','research_center/topic_pipeline_service.py',
        'research_center/topic_schema_normalizer.py','research_center/source_identity.py',
        'tests/test_ai_schedule_stability.py','tests/test_evidence_news_integrity_1113.py']
PROTECTED=['.gitignore','config.json','config/secrets.json','config/research_center.json',
           'config/company_theme_map.json','config/supply_chain_nodes.json','config/theme_profiles.json','stock_list.json',
           'logs/topic_inputs/change_20261113_224616.json','logs/topic_ai_raw/change_20261113_224616.json',
           'data/topic/change_packs/change_20261113_224616.json']
LEDGER=P/'.workdata/ai_budget/openai/openai-credits.sqlite3'
NEWS=P/'.workdata/prod/database/stock_research.db'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def save(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def git(*args,root=P):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()

def release_source():
    return load(OUT/'release-source.json')['source'] if (OUT/'release-source.json').exists() else load(OUT/'preflight.json')['source']

def release_update():
    pre=load(OUT/'preflight.json')
    actual={name:sha(W/name) for name in SOURCE}
    assert [name for name in SOURCE if actual[name]!=pre['source'][name]]==['tests/test_ai_schedule_stability.py']
    save('release-source.json',{'source':actual,'commit':git('rev-parse','HEAD',root=W),
         'reason':'Only a second obsolete November 6 news fixture date changed to date.today(); production code unchanged',
         'initial_preflight_retained':True})


def tables(path):
    with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)) as c:
        c.execute('BEGIN')
        result={}
        for (name,) in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
            digest,count=hashlib.sha256(),0
            for row in c.execute('SELECT * FROM "'+name+'" ORDER BY rowid'):
                digest.update(json.dumps(row,ensure_ascii=False,separators=(',',':')).encode())
                count+=1
            result[name]={'rows':count,'sha256':digest.hexdigest()}
        return result


def preflight():
    assert git('rev-parse','HEAD')==git('rev-parse','HEAD',root=W)==BASE
    assert not git('diff','--cached','--name-only',root=W)
    tested=load(W/'verification/evidence-news-20261113/full/source-sha256.json')
    assert all(sha(W/name)==value for name,value in tested.items())
    hb=load(P/'.runtime/bot_heartbeat.json')
    assert hb['schedule_health']['queue_size']==0 and hb['schedule_health']['current_task'] is None
    save('preflight.json',{'at':datetime.now(timezone.utc).isoformat(),'base_commit':BASE,
         'tested_source_count':len(tested),'source':{name:sha(W/name) for name in SOURCE},
         'protected':{name:sha(P/name) for name in PROTECTED},'heartbeat_before':hb,
         'formal_dirty_before':git('status','--short','--untracked-files=no'),
         'consent':'No manual task, user explicitly permitted restart; old topic pack must remain blocked',
         'new_paid_usd':'0'})
    print('Tested task-only source, idle queue and protected production data verified.')


def stopped():
    pre=load(OUT/'preflight.json')
    assert all(sha(P/name)==value for name,value in pre['protected'].items())
    save('stopped-protection.json',{'at':datetime.now(timezone.utc).isoformat(),
         'ledger_tables':tables(LEDGER),'news_tables':tables(NEWS)})
    print('All accounting and news tables captured readonly after stopping; no migrations.')


def verify_merge():
    pre=load(OUT/'preflight.json');before=load(OUT/'stopped-protection.json')
    assert all(sha(P/name)==value for name,value in pre['protected'].items())
    assert all(sha(P/name)==value for name,value in release_source().items())
    assert tables(LEDGER)==before['ledger_tables'] and tables(NEWS)==before['news_tables']
    save('merge-verification.json',{'commit':git('rev-parse','HEAD'),'all_tested_code_matches':True,
         'private_unrelated_files_and_all_accounting_news_tables_unchanged':True})
    print('Main matches tested code; unrelated data, all accounting and news tables unchanged.')


def old_pack_guard():
    from unittest.mock import patch,Mock
    from copy import deepcopy
    sys.path.insert(0,str(P))
    from research_center import topic_apply_service as service
    from research_center.topic_models import TopicChangePack
    original=load(P/'data/topic/change_packs/change_20261113_224616.json')
    assert original['extra']['evidence_review_complete'] is False
    guards={name:Mock(side_effect=AssertionError('No topic write allowed')) for name in
            ['backup_topic_files','load_topic_profiles','save_topic_profiles','save_company_topic_map',
             'save_supply_chain_nodes','save_company_knowledge_data','update_change_pack_status','write_topic_audit_log']}
    from contextlib import ExitStack
    with ExitStack() as stack:
        stack.enter_context(patch.object(service,'load_change_pack',return_value=TopicChangePack.from_dict(deepcopy(original))))
        for name,mock in guards.items():stack.enter_context(patch.object(service,name,mock))
        result=service.confirm_change_pack(original['change_id'],user_id='offline-deployment-guard-check')
    assert result.success is False and any('不可套用' in str(error) for error in result.errors)
    assert all(mock.call_count==0 for mock in guards.values())
    save('old-pack-guard.json',{'change_id':original['change_id'],'success':False,
         'errors':result.errors,'all_write_and_backup_boundaries_not_called':True,
         'old_formal_pack_not_modified_or_applied':True,'kind':'Offline actual guard function with isolated read result and forbidden writes'})
    print('Actual confirmation guard rejects the old pack before any write/backup boundary.')


def accept():
    import httpx
    pre=load(OUT/'preflight.json');before=load(OUT/'stopped-protection.json')
    config=load(P/'config.json');checks={}
    with httpx.Client(timeout=25) as client:
        for method in ['getMe','getMyCommands','getWebhookInfo']:
            try:r=client.get('https://api.telegram.org/bot'+config['api_token']+'/'+method)
            except httpx.TransportError as e:raise RuntimeError('Telegram readonly check: '+type(e).__name__) from None
            assert r.status_code==200 and r.json()['ok'],method
            data=r.json()['result']
            if method=='getMe':assert data['is_bot'];checks[method]={'ok':True,'is_bot':True}
            elif method=='getMyCommands':
                assert {'research','value_scan','macro','theme','theme_flow','theme_radar','sector_strength','radar','news','topic_maintain'} <= {row['command'] for row in data}
                checks[method]={'ok':True,'count':len(data),'all_ten_ai_entries':True}
            else:
                assert not data['url'];checks[method]={'ok':True,'polling_mode':True,'pending_updates':data['pending_update_count']}
    hb=load(P/'.runtime/bot_heartbeat.json');health=hb['schedule_health'];poll=health['telegram_transport']['channels']['polling']
    cutoff=datetime.fromisoformat(before['at'])
    assert hb['pid']!=pre['heartbeat_before']['pid'] and hb['job_queue_available']
    assert datetime.fromisoformat(hb['updated_at'])>cutoff
    assert poll['status']=='healthy' and datetime.fromisoformat(poll['last_success_at'])>cutoff
    assert health['queue_size']==0 and health['current_task'] is None
    assert health['etf_monitor']['status']=='READY' and datetime.fromisoformat(health['etf_monitor']['updated_at'])>cutoff
    assert all(sha(P/name)==value for name,value in pre['protected'].items())
    assert all(sha(P/name)==value for name,value in release_source().items())
    assert tables(LEDGER)==before['ledger_tables'] and tables(NEWS)==before['news_tables']
    save('runtime-acceptance.json',{'at':datetime.now(timezone.utc).isoformat(),'code_commit':git('rev-parse','HEAD'),
         'bot_pid':hb['pid'],'heartbeat':hb['updated_at'],'native_poll_success':poll['last_success_at'],
         'job_queue':True,'queue_size':0,'current_task':None,'etf_monitor':'READY','telegram':checks,
         'protected_data_and_all_accounting_news_tables_unchanged':True,'new_paid_usd':'0',
         'no_business_test_message_or_paid_task_sent':True,'old_pack_not_applied':True,
         'future_scheduled_output_quality_still_observation_only':True})
    save('heartbeat-after.json',hb)
    print('Fresh native polling, Telegram commands, empty queue, ETF READY and data invariants accepted.')


def publish():
    pre=load(OUT/'preflight.json');before=load(OUT/'stopped-protection.json')
    local=git('rev-parse','HEAD');remote=git('ls-remote','origin','refs/heads/main').split()[0]
    assert local==remote
    assert all(sha(P/name)==value for name,value in pre['protected'].items())
    assert all(sha(P/name)==value for name,value in release_source().items())
    assert tables(LEDGER)==before['ledger_tables']
    save('git-publication.json',{'at':datetime.now(timezone.utc).isoformat(),'main':local,'origin_main':remote,
         'matches':True,'only_this_task_committed':True,'unrelated_dirty_and_old_pack_unchanged':True,
         'all_accounting_unchanged':True,'unknown_reserves_unchanged':True,'new_paid_usd':'0','restart_count':1})
    print('main == origin/main:',local)


def stage_release():
    import re,zipfile,io
    evidence=W/'verification/evidence-news-20261113'
    files=SOURCE+['README.md']+[str(p.relative_to(W)).replace('\\','/') for p in evidence.iterdir() if p.is_file()]
    files += ['verification/evidence-news-20261113/'+name for name in
              ['full/session.json','full/details.json','full/source-sha256.json',
               'related-final/session.json','related-final/source-sha256.json',
               'focused/details.json','focused/session.json']]
    assert not git('diff','--cached','--name-only',root=W)
    secrets=[]
    def scan(name,content):
        if name.endswith('.zip'):
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                for member in archive.namelist():
                    if not member.endswith('/'):scan(name+':'+member,archive.read(member))
        elif re.search(rb'(?:sk-(?:proj-)?[A-Za-z0-9_-]{30,}|eyJ[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{20,}|[0-9]{8,12}:[A-Za-z0-9_-]{30,})',content):
            secrets.append(name)
    for name in files:scan(name,(W/name).read_bytes())
    assert not secrets, 'Possible secrets in '+str(secrets)
    subprocess.run(['git','add','--',*files],cwd=W,check=True)
    staged=git('diff','--cached','--name-only',root=W).splitlines()
    assert sorted(staged)==sorted(files)
    subprocess.run(['git','diff','--cached','--check'],cwd=W,check=True)
    print(json.dumps({'staged_count':len(staged),'secret_scan':'clear','files':staged},ensure_ascii=False,indent=2))


def collect():
    import zipfile
    results=P/'verification/evidence-news-20261113/deployment'
    final=load(results/'final-full/session.json')
    assert final['exit_status']==0 and final['source_unchanged']
    copied=[]
    for folder in ['main-regression','main-final','main-fixed','final-full']:
        for name in ['session.json','source-sha256.json','details.json','fixture-restore.json']:
            source=results/folder/name
            if not source.exists():continue
            target=OUT/folder/name
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(source.read_bytes())
            assert sha(target)==sha(source)
            copied.append(str(target.relative_to(W)))
    with zipfile.ZipFile(OUT/'deployment-helper.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
        archive.write(Path(__file__),'deploy.py')
        archive.write(P/'.codex-tmp/ds/evidence-news-main-1114/final_tests.py','final_tests.py')
    print(json.dumps({'evidence_copied_and_hashed':copied,'helpers_archived':True},ensure_ascii=False,indent=2))


{'preflight':preflight,'stopped':stopped,'merge':verify_merge,'old-pack':old_pack_guard,'accept':accept,'publish':publish,'stage':stage_release,'release-update':release_update,'collect':collect}[sys.argv[1]]()
