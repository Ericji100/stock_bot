from pathlib import Path
from zipfile import ZipFile
import json
import os
import sys

ROOT=Path('D:/code/stock_ai_bot')
WORK=Path(__file__).resolve().parent
OUT=ROOT/'verification/evidence-news-20261113/deployment/final-full'
assert Path(json.loads((WORK/'.codex-task.json').read_text())['project'])==ROOT
OUT.mkdir(parents=True,exist_ok=True)
os.environ.update(TEMP=str(WORK),TMP=str(WORK),STOCK_AI_BOT_WORKDATA_ROOT=str(WORK/'workdata'),
    CODEX_TASK_TEST_ROOT=str(WORK/'t'),DEEPSEEK_BUDGET_TEST_ROOT=str(WORK/'b'),
    OPENAI_API_KEY='',OPENAI_SECONDARY_API_KEY='',DEEPSEEK_API_KEY='offline-placeholder')
sys.path.insert(0,str(ROOT))
mode=sys.argv.pop(1)
assert mode in {'restore','full'}
with ZipFile(Path('D:/code/_codex_worktrees/ai-schedule-stability/stock_ai_bot/verification/ai-schedule-stability-20261107/live/offline-test-helpers.zip')) as z:
    script=z.read('restore_fixtures.py' if mode=='restore' else 'full_suite.py').decode()
script=script.replace('ROOT = Path(__file__).resolve().parents[3]',f'ROOT = Path({str(ROOT)!r})')
script=script.replace('ROOT=Path(__file__).resolve().parents[3]',f'ROOT=Path({str(ROOT)!r})')
script=script.replace("OUT = ROOT / 'verification/ai-schedule-stability-20261107/live'",f'OUT = Path({str(OUT)!r})')
exec(compile(script,'archived-offline-helper.py','exec'),{'__file__':str(__file__)})
