"""Replay saved November 13 inputs; no external HTTP or production writes."""
from contextlib import closing
from copy import deepcopy
from dataclasses import asdict
from datetime import date, datetime
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
from zipfile import ZipFile
from unittest.mock import patch

W = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
P = Path('D:/code/stock_ai_bot')
OUT = W/'verification/evidence-news-20261113'
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0,str(W))
assert Path(json.loads((WORK/'.codex-task.json').read_text())['project']) == W
os.environ.update(TEMP=str(WORK), TMP=str(WORK), STOCK_AI_BOT_WORKDATA_ROOT=str(WORK/'workdata'),
    DEEPSEEK_BUDGET_TEST_ROOT=str(WORK/'b'), CODEX_TASK_TEST_ROOT=str(WORK/'t'),
    OPENAI_API_KEY='', OPENAI_SECONDARY_API_KEY='', DEEPSEEK_API_KEY='offline-placeholder')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


def rows(path, query, args=()):
    with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)) as conn:
        conn.row_factory=sqlite3.Row
        return [dict(r) for r in conn.execute(query,args)]


def protection():
    paths=['main.py','research_center/news_service.py','research_center/topic_input_package.py',
        'research_center/topic_citation_audit.py','research_center/topic_pipeline_service.py',
        'research_center/entity_resolver.py','config.json','config/secrets.json','config/research_center.json',
        'config/company_theme_map.json','config/supply_chain_nodes.json','config/theme_profiles.json',
        'logs/topic_inputs/change_20261113_224616.json','logs/topic_ai_raw/change_20261113_224616.json',
        'data/topic/change_packs/change_20261113_224616.json']
    requests=rows(P/'.workdata/ai_budget/openai/openai-credits.sqlite3',
        "SELECT * FROM requests WHERE run_id in (?,?) OR status='unknown' ORDER BY rowid",
        ('856596e9a4ec4adfb24bccd3c2801128','ce50b07bb9c74e6daa752c72cf51c166'))
    return {'files':{name:sha(P/name) for name in paths},
            'requests_sha256':hashlib.sha256(json.dumps(requests,sort_keys=True).encode()).hexdigest(),
            'requests':len(requests), 'unknown_count':sum(r['status']=='unknown' for r in requests)}


def block_network():
    import httpx,requests,urllib.request
    def denied(*args,**kwargs):
        raise AssertionError('Offline replay: external network prohibited')
    httpx.Client.send=denied
    httpx.AsyncClient.send=denied
    requests.sessions.Session.request=denied
    urllib.request.urlopen=denied


def replay():
    block_network()
    from research_center.topic_models import TopicChangePack, TopicChangeMode
    from research_center.topic_pipeline_service import run_topic_pipeline
    from research_center.topic_maintain_service import _load_prompt, _render_prompt, _parse_ai_json_response
    from research_center.topic_input_package import merge_topic_sources, topic_stage_variables
    from research_center.topic_apply_service import resolve_action_targets, coalesce_topic_updates, validate_action_targets
    from research_center.topic_citation_audit import (restore_topic_source_quotes,quarantine_topic_source_leads,
        quarantine_unproven_company_claims,audit_topic_citations)
    from research_center.topic_schema_normalizer import resolve_topic_company_identities
    from research_center.entity_resolver import company_aliases_from_sources
    from research_center.news_models import NewsItem
    from research_center.news_repository import NewsRepository
    from research_center import news_service as news
    from research_center.deepseek_service import ai_task
    before=protection()
    save('formal-protection-before.json',before)
    original_data=read(P/'logs/topic_inputs/change_20261113_224616.json')
    data=deepcopy(original_data)
    original=read(P/'data/topic/change_packs/change_20261113_224616.json')
    raw=read(P/'logs/topic_ai_raw/change_20261113_224616.json')
    stages={row['stage']:row for row in raw['stages']}
    calls=[]
    def reused(prompt,stage):
        assert stage in stages, ('Unexpected extra model stage',stage)
        calls.append(stage)
        path=WORK/'prompts'/f'{stage}.md'
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(prompt,encoding='utf-8')
        return _parse_ai_json_response(stages[stage]['raw'])
    variables={'mode':'update','report_date':'2026-11-13'}
    def saved_layout(candidates,*args,**kwargs):
        by_id={row['theme_id']:row for row in candidates}
        batches=[[by_id[cid] for cid in row['candidate_ids']] for row in original['extra']['detail_review']['batches']]
        assert {r['theme_id'] for batch in batches for r in batch} == set(by_id)
        return batches
    # Reuse each response only with its originally reviewed candidates, not a new layout.
    with ai_task('topic_maintain',background=True,report_date='2026-11-13'), \
         patch('research_center.topic_pipeline_service._full_evidence_detail_batches',side_effect=saved_layout):
        pack,logs=run_topic_pipeline(mode=TopicChangeMode.UPDATE,ai_model='gpt-6-luna',
            change_id='isolated-replay-1113',iso_ts='2026-11-13T22:46:16+0800',structured_data=data,
            prompt_variables=variables,load_prompt=_load_prompt,render_prompt=_render_prompt,
            call_ai_json=reused,require_full_ai=True,
            prompt_capacity=lambda *args,**kwargs:{'fits':True,'scope':'offline provider capacity stub; not a new token count'})
    assert calls==list(stages),calls
    profiles=data['existing_topic_profiles']
    resolve_action_targets(pack,profiles)
    coalesce_topic_updates(pack,profiles)
    restore_topic_source_quotes(pack,data)
    quarantine_topic_source_leads(pack,data)
    quarantine_unproven_company_claims(pack,data)
    audit=audit_topic_citations(pack,data)
    targets=validate_action_targets(pack,profiles)
    assert len(pack.actions)==8 and pack.extra['detail_review']['ai_completed_count']==8, (
        len(pack.actions),pack.extra['detail_review'],[{k:v for k,v in row.items() if k in {'stage','error','warning'}} for row in logs])
    assert targets['passed']
    merged=merge_topic_sources(data)
    assert len(merged)==len({r['source_id'] for r in merged})==294
    assert all(any(old.get('url')==new.get('url') and
        str(old.get('content') or old.get('snippet') or '') in str(new.get('content') or new.get('snippet') or '')
        for new in merged) for old in original['sources'])
    assert audit['blocking_count']==6 and all(r['reason']=='supporting_quote_not_in_body' for r in audit['issues'])
    assert not audit['passed']
    pack.extra.update(citation_audit=audit, action_target_audit=targets, evidence_review_complete=False, ai_status='partial_success')
    save('topic-replayed-pack.json',pack.to_dict())
    aliases=pack.extra['company_identity_audit']
    topic={'replayed_saved_model_stages':calls,'selected':8,'ai_completed':8,
        'provider_capacity':'Offline response stub only; production capacity checks unchanged, no new token-count API request',
        'batch_scope':'Frozen recorded four-pair layout for saved-response attribution; not a new model execution',
        'original_blocking_count':original['extra']['citation_audit']['blocking_count'],
        'remaining_blocking_count':audit['blocking_count'],'strict_quote_failures_retained':audit['issues'],
        'unique_source_ids':len(merged),'all_original_source_bodies_preserved':True,'target_audit_passed':targets['passed'],
        'alias_pending':[r for r in aliases if r['status']=='alias_pending'],
        'verified_aliases':company_aliases_from_sources(data),'applicable':False,
        'no_claims_promoted':all(x.get('verification_status')=='candidate' for a in pack.actions for x in a.company_relations)}
    save('topic-replay.json',topic)

    db=P/'.workdata/prod/database/stock_research.db'
    inputs=rows(db,"SELECT record,status FROM news_classification_inputs WHERE classified_at LIKE '2026-11-13T18:%'")
    originals={json.loads(r['record'])['url']:NewsItem.from_dict(json.loads(r['record'])) for r in inputs}
    requests=rows(P/'.workdata/ai_budget/openai/openai-credits.sqlite3',
        "SELECT id,detail FROM requests WHERE run_id=? AND operation='model' ORDER BY rowid",
        ('856596e9a4ec4adfb24bccd3c2801128',))
    classified=[]
    for request in requests:
        body=read(P/'.workdata/ai_budget/openai/requests'/f"{request['id']}-request.json")['body']
        blocks=re.findall(r'```json\s*([\s\S]*?)```',body['input'])
        batches=[json.loads(block) for block in blocks if block.lstrip().startswith('[')]
        batch=next(value for value in batches if value and isinstance(value[0],dict) and 'url' in value[0] and 'id' in value[0])
        response=read(Path(json.loads(request['detail'])['response_path']))
        text=''.join(part.get('text','') for item in response['output'] if item.get('type')=='message' for part in item.get('content',[]))
        parsed=_parse_ai_json_response(text)
        selected=[deepcopy(originals[item['url']]) for item in batch]
        for item, original_input in zip(selected, batch, strict=True):
            item.id = str(original_input['id'])
        with ai_task('news',background=True,report_date='2026-11-13'):
            classified.extend(news._apply_classification_meta(selected,parsed))
    assert len(classified)==30 and sum('ai_excluded' in it.tags for it in classified)==7, (
        len(classified),sum('ai_excluded' in it.tags for it in classified),[(it.id,it.title,it.tags) for it in classified if 'local_rule_fallback' in it.tags])
    coverage=news.news_category_coverage(classified)
    assert coverage['usable_category_counts']['supply_chain']>=1
    futures=[it for it in classified if '台指期夜盤41K' in it.title.replace(' ','')]
    assert len(futures)==2 and all(it.category=='market_focus' for it in futures)
    repo=NewsRepository(WORK/'news-replay.sqlite3')
    repo.save_many(classified)
    assert all(repo.get_by_url(it.url).full_text==it.full_text for it in classified)
    save('news-replayed-items.json',[it.to_dict() for it in classified])
    save('news-replay.json',{'original_classifier_responses':len(requests),'reviewed_items':len(classified),
        'retained_articles':23,'excluded_retained':7,'category_coverage':coverage,
        'futures_category':[(it.title,it.category) for it in futures],
        'all_body_text_preserved':True,'new_model_calls':0,'freshness_not_upgraded':True})
    assert protection()==before
    save('formal-protection-final.json',{'unchanged':True,**protection(),'new_paid_usd':'0','external_http_calls':0})
    print('Replay passed: 5 saved topic stages, all 8 themes; citation blockers 17 -> 6 (real quote gaps remain).')
    print('10 saved news classifier responses: 30 judged, 23 retained, 7 excluded, futures corrected, supply-chain covered.')


mode=sys.argv.pop(1)
if mode=='replay':
    replay()
elif mode=='protect':
    before=read(OUT/'formal-protection-before.json')
    current=protection()
    assert current==before
    save('formal-protection-final.json',{'unchanged':True,**current,'new_paid_usd':'0','external_http_calls':0})
    print('Formal source/config/raw evidence, scheduled accounting and all unknown rows remain unchanged.')
elif mode in {'restore','full'}:
    with ZipFile(W/'verification/ai-schedule-stability-20261107/live/offline-test-helpers.zip') as z:
        script=z.read('restore_fixtures.py' if mode=='restore' else 'full_suite.py').decode()
    script=script.replace('ROOT = Path(__file__).resolve().parents[3]',f'ROOT = Path({str(W)!r})')
    script=script.replace('ROOT=Path(__file__).resolve().parents[3]',f'ROOT=Path({str(W)!r})')
    script=script.replace("OUT = ROOT / 'verification/ai-schedule-stability-20261107/live'",f'OUT = Path({str(OUT)!r})')
    exec(compile(script,'archived-offline-helper.py','exec'),{'__file__':str(__file__)})
else:
    raise ValueError(mode)
