"""Scoped deployment evidence. No AI/search calls or financial migrations."""
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

W = Path('D:/code/_codex_worktrees/ai-schedule-stability/stock_ai_bot')
P = Path('D:/code/stock_ai_bot')
OUT = W/'verification/news-dispatch-20261112/deployment'
OUT.mkdir(parents=True, exist_ok=True)
BASE = 'c4e73f748f27c94124c6b142c3346c9a673cf43e'
SOURCE = ['main.py', 'research_center/ai_execution_control.py', 'research_center/deepseek_service.py',
          'research_center/deepseek_search_service.py', 'research_center/news_service.py',
          'research_center/openai_service.py', 'tests/test_news_search_dispatch.py']
PROTECTED = ['.gitignore', 'config.json', 'config/secrets.json', 'config/research_center.json',
             'config/company_theme_map.json', 'config/supply_chain_nodes.json', 'config/theme_profiles.json', 'stock_list.json']
LEDGER = P/'.workdata/ai_budget/openai/openai-credits.sqlite3'
NEWS = P/'.workdata/prod/database/stock_research.db'


def save(name, data):
    (OUT/name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    return data


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args, root=P):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()


def tables(path):
    with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro', uri=True)) as conn:
        conn.execute('BEGIN')
        out = {}
        for (table,) in conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
            digest, count = hashlib.sha256(), 0
            for row in conn.execute('SELECT * FROM "'+table+'" ORDER BY rowid'):
                digest.update(json.dumps(row, ensure_ascii=False, separators=(',', ':')).encode())
                count += 1
            out[table] = {'rows': count, 'sha256': digest.hexdigest()}
        return out


def preflight():
    assert git('rev-parse', 'HEAD') == BASE == git('rev-parse', 'HEAD', root=W)
    assert git('diff', '--cached', '--name-only', root=W) == ''
    hashes = json.loads((W/'verification/news-dispatch-20261112/full/source-sha256.json').read_text())
    assert all(sha(W/name) == value for name, value in hashes.items())
    protected = {name: sha(P/name) for name in PROTECTED}
    save('preflight.json', {'at': datetime.now(timezone.utc).isoformat(), 'base_commit': BASE,
         'source': {name: sha(W/name) for name in SOURCE}, 'tested_source_count': len(hashes),
         'protected': protected, 'dirty_before': git('status', '--short', '--untracked-files=no'),
         'heartbeat_before': json.loads((P/'.runtime/bot_heartbeat.json').read_text()),
         'restart_consent': 'User confirmed no manual task; interruption of stopping scheduled backfill allowed',
         'new_paid_usd': '0'})
    print('Scoped source manifest and protected production files verified; all tested source hashes unchanged.')


def stopped():
    pre = json.loads((OUT/'preflight.json').read_text())
    assert all(sha(P/name) == value for name, value in pre['protected'].items())
    save('stopped-protection.json', {'at': datetime.now(timezone.utc).isoformat(),
         'ledger_tables': tables(LEDGER), 'news_tables': tables(NEWS)})
    (OUT/'heartbeat-before-restart.json').write_bytes((P/'.runtime/bot_heartbeat.json').read_bytes())
    print('Stopped production accounting/news table snapshots saved; no data changed.')


def verify_merge():
    pre = json.loads((OUT/'preflight.json').read_text())
    assert all(sha(P/name) == value for name, value in pre['source'].items())
    assert all(sha(P/name) == value for name, value in pre['protected'].items())
    stopped_proof = json.loads((OUT/'stopped-protection.json').read_text())
    assert tables(LEDGER) == stopped_proof['ledger_tables']
    assert tables(NEWS) == stopped_proof['news_tables']
    save('merge-verification.json', {'commit': git('rev-parse', 'HEAD'), 'tested_code_matches': True,
         'protected_files_and_all_accounting_news_tables_unchanged': True, 'new_paid_usd': '0'})
    print('Main code matches tested source; unrelated files, all accounting and news tables unchanged.')


def accept():
    import httpx
    pre = json.loads((OUT/'preflight.json').read_text())
    stopped_proof = json.loads((OUT/'stopped-protection.json').read_text())
    config = json.loads((P/'config.json').read_text(encoding='utf-8-sig'))
    checks = {}
    with httpx.Client(timeout=25) as client:
        for method in ['getMe', 'getMyCommands', 'getWebhookInfo']:
            try:
                response = client.get('https://api.telegram.org/bot'+config['api_token']+'/'+method)
            except httpx.TransportError as exc:
                raise RuntimeError('Telegram readonly check failed: '+type(exc).__name__) from None
            assert response.status_code == 200 and response.json()['ok'], method
            data = response.json()['result']
            if method == 'getMyCommands':
                commands = {row['command'] for row in data}
                assert {'research','value_scan','macro','theme','theme_flow','theme_radar','sector_strength','radar','news','topic_maintain'} <= commands
                checks[method] = {'ok': True, 'count': len(data), 'all_ten_ai_entries': True}
            elif method == 'getWebhookInfo':
                assert not data['url']
                checks[method] = {'ok': True, 'polling_mode': True, 'pending_updates': data['pending_update_count']}
            else:
                assert data['is_bot']
                checks[method] = {'ok': True, 'is_bot': True}
    hb = json.loads((P/'.runtime/bot_heartbeat.json').read_text())
    health = hb['schedule_health']
    poll = health['telegram_transport']['channels']['polling']
    assert hb['pid'] != pre['heartbeat_before']['pid'] and hb['job_queue_available']
    cutoff = datetime.fromisoformat(stopped_proof['at'])
    assert datetime.fromisoformat(hb['updated_at']) > cutoff
    assert poll['status'] == 'healthy' and datetime.fromisoformat(poll['last_success_at']) > cutoff
    assert health['queue_size'] == 0 and health['current_task'] is None
    assert health['etf_monitor']['status'] == 'READY'
    assert tables(LEDGER) == stopped_proof['ledger_tables']
    assert tables(NEWS) == stopped_proof['news_tables']
    assert all(sha(P/name) == value for name, value in pre['protected'].items())
    assert all(sha(P/name) == value for name, value in pre['source'].items())
    save('runtime-acceptance.json', {'at': datetime.now(timezone.utc).isoformat(), 'commit': git('rev-parse','HEAD'),
        'bot_pid': hb['pid'], 'heartbeat_at': hb['updated_at'], 'native_polling_success': poll['last_success_at'],
        'job_queue_available': True, 'current_task': None, 'queue_size': 0, 'etf_monitor': 'READY',
        'telegram': checks, 'all_ledger_and_news_tables_unchanged': True, 'protected_files_unchanged': True,
        'new_paid_usd': '0', 'no_business_test_message_sent': True,
        'future_scheduled_news_not_live_replayed': True})
    save('heartbeat-after.json', hb)
    print('Native polling, Telegram readonly endpoints, job queue, ETF READY and full accounting/news invariants accepted.')


def publication():
    pre = json.loads((OUT/'preflight.json').read_text())
    local = git('rev-parse','HEAD')
    remote = git('ls-remote','origin','refs/heads/main').split()[0]
    assert local == remote
    assert all(sha(P/name) == value for name, value in pre['protected'].items())
    assert all(sha(P/name) == value for name, value in pre['source'].items())
    assert tables(LEDGER) == json.loads((OUT/'stopped-protection.json').read_text())['ledger_tables']
    save('git-publication.json', {'at': datetime.now(timezone.utc).isoformat(), 'main': local, 'origin_main': remote,
        'matches': True, 'only_this_task_in_new_commits': True, 'unrelated_dirty_files_unchanged': True,
        'all_accounting_unchanged': True, 'new_paid_usd': '0', 'restart_count': 1})
    print('Verified main == origin/main:',local)


{'preflight': preflight, 'stopped': stopped, 'merge': verify_merge, 'accept': accept, 'publish': publication}[sys.argv[1]]()
