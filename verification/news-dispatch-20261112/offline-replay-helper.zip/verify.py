from contextlib import closing
from dataclasses import asdict
from datetime import date
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
from types import SimpleNamespace
from unittest.mock import patch
from zipfile import ZipFile, ZIP_DEFLATED
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
OUT = ROOT / 'verification/news-dispatch-20261112'
FORMAL = Path('D:/code/stock_ai_bot')
RUN = 'e1a7052b712a43249058d7ce97d9983c'
UNKNOWN = 'd4a9b7e11da346dc8d4f0d6241c7e0a4'
sys.path.insert(0, str(ROOT))
assert Path(json.loads((WORK / '.codex-task.json').read_text())['project']) == ROOT
OUT.mkdir(parents=True, exist_ok=True)
os.environ.update(PYTHONUTF8='1', TEMP=str(WORK), TMP=str(WORK), STOCK_AI_BOT_WORKDATA_ROOT=str(WORK/'workdata'),
                  CODEX_TASK_TEST_ROOT=str(WORK/'t'), DEEPSEEK_BUDGET_TEST_ROOT=str(WORK/'b'),
                  DEEPSEEK_API_KEY='offline-test-key', OPENAI_API_KEY='', OPENAI_SECONDARY_API_KEY='')


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def read_rows(path, sql, args=()):
    with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro', uri=True)) as conn:
        conn.row_factory = sqlite3.Row
        return [dict(row) for row in conn.execute(sql, args)]


def protected():
    ledger = FORMAL/'.workdata/ai_budget/openai/openai-credits.sqlite3'
    rows = read_rows(ledger, 'SELECT * FROM requests WHERE run_id=? ORDER BY rowid', (RUN,))
    sources = read_rows(FORMAL/'.workdata/prod/database/stock_research.db',
                       'SELECT * FROM news_discovery_sources WHERE run_id=? ORDER BY rowid', (RUN,))
    files = ['main.py', 'research_center/ai_execution_control.py', 'research_center/openai_service.py',
             'research_center/deepseek_service.py', 'research_center/deepseek_search_service.py',
             'research_center/news_service.py', 'config/research_center.json', 'stock_list.json',
             'config/company_theme_map.json', 'config/supply_chain_nodes.json', 'config/theme_profiles.json']
    return {'requests_sha256': digest(rows), 'sources_sha256': digest(sources),
            'unknown': next(row for row in rows if row['id'] == UNKNOWN),
            'files': {name: hashlib.sha256((FORMAL/name).read_bytes()).hexdigest() for name in files}}, rows, sources


def restore():
    with ZipFile(ROOT/'verification/ai-schedule-stability-20261107/live/offline-test-helpers.zip') as z:
        script = z.read('restore_fixtures.py').decode()
    script = script.replace('ROOT = Path(__file__).resolve().parents[3]', f'ROOT = Path({str(ROOT)!r})')
    script = script.replace("OUT = ROOT / 'verification/ai-schedule-stability-20261107/live'", f'OUT = Path({str(OUT)!r})')
    exec(compile(script, 'archived-restore-fixtures.py', 'exec'), {'__file__': str(__file__)})


def replay():
    import httpx
    from research_center.ai_execution_control import CONTROL, ExecutionControl, WorkStopped, execution_scope, require_search_dispatch_time
    from research_center.deepseek_service import ai_task
    from research_center.models import SourceItem
    from research_center.news_repository import NewsRepository
    from research_center import news_service as news
    from tests.test_ai_schedule_stability import ledger_client, request_rows

    work = WORK / ('replay-' + uuid4().hex[:6])
    work.mkdir()
    before, requests, versions = protected()
    (OUT/'formal-protection-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2), encoding='utf-8')
    assert before['unknown']['status'] == 'unknown' and before['unknown']['actual'] is None
    assert before['unknown']['estimate'] == '0.288884'
    # An isolated snapshot preserves all versions; no production DB is opened for writing.
    with sqlite3.connect(work/'original-sources.sqlite3') as conn:
        conn.execute('CREATE TABLE IF NOT EXISTS originals (record TEXT)')
        assert conn.execute('SELECT count(*) FROM originals').fetchone()[0] == 0
        conn.executemany('INSERT INTO originals VALUES (?)', [(row['record'],) for row in versions])
    timeline, raw_hashes, replayed = [], {}, []
    for index, row in enumerate(requests, 1):
        raw_path = FORMAL/'.workdata/ai_budget/openai/requests'/f"{row['id']}-request.json"
        raw = json.loads(raw_path.read_text(encoding='utf-8'))
        raw_hashes[raw_path.name] = hashlib.sha256(raw_path.read_bytes()).hexdigest()
        remaining = raw['request_timeout']['read']
        token = CONTROL.set(ExecutionControl(remaining, clock=lambda: 0.))
        decision = 'dispatch'
        try:
            with ai_task('news', background=True):
                require_search_dispatch_time(600)
        except WorkStopped as exc:
            decision = exc.status
        finally:
            CONTROL.reset(token)
        timeline.append({'sequence': index, 'request_id': row['id'], 'original_status': row['status'],
                         'read_time_limit_seconds': remaining, 'new_dispatch_decision': decision})
        response_path = raw_path.with_name(f"{row['id']}-response.json")
        if row['status'] != 'success':
            assert row['id'] == UNKNOWN and not response_path.exists()
            continue
        data = json.loads(response_path.read_text(encoding='utf-8'))
        raw_hashes[response_path.name] = hashlib.sha256(response_path.read_bytes()).hexdigest()
        calls = []
        def respond(request):
            calls.append(1)
            assert json.loads(request.content) == raw['body']
            return httpx.Response(200, json=data)
        ledger, client = ledger_client(work/'responses'/str(index), httpx.MockTransport(respond))
        client = client.with_output_limit(raw['body']['max_output_tokens'])
        with ai_task('news', background=True), execution_scope(1200):
            result, diagnostics = client._request(raw['body']['input'], search=True)
        assert result == data and len(calls) == 1 and request_rows(ledger)[0][0] == 'success'
        replayed.append(row['id'])
    assert len(replayed) == 18 and len(requests) == 19
    assert timeline[-1]['new_dispatch_decision'] == 'insufficient_search_time'

    repo = NewsRepository(work/'classification-replay.sqlite3')
    with sqlite3.connect(repo.db_path) as conn:
        conn.executemany('INSERT INTO news_discovery_sources VALUES (?,?,?,?,?)',
            [(r['run_id'], r['record_sha256'], r['url'], r['record'], r['saved_at']) for r in versions])
    sources = [SourceItem(**json.loads(row['record'])) for row in versions]
    saved = [asdict(item) for item in sources]
    classifier_calls = []
    def classify(*args):
        classifier_calls.append(args[2])
        return SimpleNamespace(raw={str(i): {'category': 'company_news', 'summary': 'Offline control-flow placeholder, not a live AI conclusion'} for i in range(30)})
    center = SimpleNamespace(config=SimpleNamespace(deepseek_only=True, deepseek_model='offline'),
                             deepseek_organizer=SimpleNamespace(model='offline', account=SimpleNamespace(cached=lambda _: None, cache=lambda *a: None)))
    diag = {'complete': False, 'stop_reason': 'insufficient_search_time',
            'deferred_search': {'request_id': UNKNOWN, 'query': json.loads((FORMAL/'.workdata/ai_budget/openai/requests'/f'{UNKNOWN}-request.json').read_text(encoding='utf-8'))['body']['input']}}
    from research_center.deepseek_search_service import DeepSeekSearchService
    _, native = ledger_client(work/'dispatch-block', httpx.MockTransport(lambda _: (_ for _ in ()).throw(AssertionError('No new HTTP allowed'))))
    service = DeepSeekSearchService(native)
    service.search = lambda query, **kwargs: native.search(query, kwargs.get('report_date', ''))
    center.deepseek_search = service
    def discovery_flow(_runner, request, **kwargs):
        control = CONTROL.get()
        control.deadline = control.clock() + 37.049111
        return service.discover(request, [{'label': 'saved_news_time_boundary', 'queries': ['remaining query']}],
                                seed_sources=sources)
    with patch('research_center.orchestrator._GeminiDiscoveryRunner.run_discovery_flow', discovery_flow), \
         patch.object(news, '_enrich_sources_with_web_fetch'), \
         patch.object(news, '_scheduled_news_batch_guard'), \
         patch.object(news, '_call_news_classifier', side_effect=classify), \
         patch('stock_ai_bot.portfolio.portfolio_manager.load_portfolio', return_value={}), \
         ai_task('news', background=True, report_date='2026-11-12'), execution_scope(2400):
        items, meta = news.run_news_refresh(center, repo)
    assert classifier_calls and meta['selected_classification_complete'] and meta['classification_status'] == 'partial_success'
    assert [asdict(item) for item in sources] == saved
    assert meta['minimax_diagnostics']['stop_reason'] == 'insufficient_search_time'
    assert meta['minimax_diagnostics']['deferred_search']['query'] == 'remaining query'
    with sqlite3.connect(repo.db_path) as conn:
        restored = conn.execute('SELECT record FROM news_discovery_sources WHERE run_id=? ORDER BY rowid', (RUN,)).fetchall()
    assert [r[0] for r in restored] == [r['record'] for r in versions]
    after, _, _ = protected()
    assert before == after
    for name, sha in raw_hashes.items():
        assert hashlib.sha256((FORMAL/'.workdata/ai_budget/openai/requests'/name).read_bytes()).hexdigest() == sha
    report = {'original_run_id': RUN, 'real_external_requests': 0, 'new_actual_cost_usd': '0',
        'original_settled_cost_usd': str(sum((Decimal(r['actual'] or '0') for r in requests), Decimal(0))),
        'unknown_reserved_usd': before['unknown']['estimate'], 'unknown_status_preserved': True,
        'actual_response_replays': len(replayed), 'raw_sha256': raw_hashes, 'dispatch_timeline': timeline,
        'all_source_versions': len(versions), 'unique_urls': len({r['url'] for r in versions}),
        'all_original_source_versions_unchanged': True, 'input_sources_not_mutated': True,
        'classification_test': {'kind': 'mock-only control flow, NOT a real AI report',
            'native_discovery_checkpoint_and_scope_reset': True,
            'calls': len(classifier_calls), 'selected_complete': meta['selected_classification_complete'],
            'ai_tagged_placeholders': meta['ai_classified_count'], 'search_complete': meta['search_complete'],
            'classification_status': meta['classification_status'], 'deferred_count': meta['deferred_classification_count']},
        'formal_protection_unchanged': before == after}
    (OUT/'tonight-replay.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({key:value for key,value in report.items() if key not in {'raw_sha256','dispatch_timeline'}}, ensure_ascii=False))


mode = sys.argv.pop(1)
if mode == 'restore':
    restore()
elif mode == 'replay':
    replay()
elif mode == 'full':
    with ZipFile(ROOT/'verification/ai-schedule-stability-20261107/live/offline-test-helpers.zip') as z:
        script = z.read('full_suite.py').decode()
    script = script.replace('ROOT=Path(__file__).resolve().parents[3]', f'ROOT=Path({str(ROOT)!r})')
    exec(compile(script, 'archived-full-suite.py', 'exec'), {'__file__': str(__file__)})
elif mode == 'protect':
    current, _, _ = protected()
    before = json.loads((OUT/'formal-protection-before.json').read_text(encoding='utf-8'))
    assert current == before
    proof = {'formal_files_and_run_records_unchanged': True,
             'unknown_status': current['unknown']['status'],
             'unknown_actual': current['unknown']['actual'],
             'unknown_reserved_usd': current['unknown']['estimate']}
    (OUT/'formal-protection-final.json').write_text(json.dumps(proof, indent=2), encoding='utf-8')
    print(proof)
else:
    raise ValueError(mode)
