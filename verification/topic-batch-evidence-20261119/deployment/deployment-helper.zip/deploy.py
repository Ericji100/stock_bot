"""Scoped topic batch deployment evidence; no model or search requests."""
from contextlib import closing, ExitStack
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
from unittest.mock import Mock, patch
import zipfile

W = Path('D:/code/_codex_worktrees/ai-schedule-stability/stock_ai_bot')
P = Path('D:/code/stock_ai_bot')
BASE = 'd5b021bd4021e361a8073711e5ed6d7b2e85b464'
ROOT = W / 'verification/topic-batch-evidence-20261119'
OUT = ROOT / 'deployment'
SOURCE = ['research_center/topic_batch_evidence.py', 'research_center/topic_quote_binding.py',
    'research_center/topic_input_package.py', 'research_center/topic_pipeline_service.py',
    'research_center/topic_maintain_service.py', 'prompt/topic/topic_detail_expand.md',
    'tests/test_topic_batch_evidence.py', 'tests/test_reader_quality_rules.py']
PROTECTED = ['.gitignore','config.json','config/secrets.json','config/research_center.json',
    'config/company_theme_map.json','config/supply_chain_nodes.json','config/theme_profiles.json',
    'config/company_knowledge.json','stock_list.json']
for day in ['20261113_224616','20261117_234022']:
    PROTECTED += [f'logs/topic_inputs/change_{day}.json', f'logs/topic_ai_raw/change_{day}.json',
        f'data/topic/change_packs/change_{day}.json']
LEDGER = P / '.workdata/ai_budget/openai/openai-credits.sqlite3'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(name, value):
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def git(*args, root=P):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

def tables(path):
    with closing(sqlite3.connect(path.as_uri()+'?mode=ro',uri=True)) as c:
        c.execute('BEGIN')
        result = {}
        for (name,) in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
            rows = c.execute('SELECT * FROM "'+name+'" ORDER BY rowid').fetchall()
            result[name] = {'rows':len(rows), 'sha256':hashlib.sha256(json.dumps(rows,ensure_ascii=False).encode()).hexdigest()}
        return result

def preflight():
    assert git('rev-parse','HEAD') == git('rev-parse','HEAD',root=W) == BASE
    assert not git('diff','--cached','--name-only') and not git('diff','--cached','--name-only',root=W)
    assert read(ROOT/'release-full/session.json')['exit_status'] == 0
    hashes = read(ROOT/'release-full/source-sha256.json')
    assert all(sha(W/name) == digest for name,digest in hashes.items())
    assert all(git('show',BASE+':'+name,root=W) == git('show',BASE+':'+name) for name in SOURCE if (P/name).exists())
    save('preflight.json', {'at':datetime.now(timezone.utc).isoformat(), 'base':BASE,
        'source':{name:sha(W/name) for name in SOURCE},
        'protected':{name:sha(P/name) for name in PROTECTED},
        'ledger':tables(LEDGER), 'formal_dirty':git('status','--short','--untracked-files=no'),
        'tested_source_count':len(hashes), 'heartbeat_before':read(P/'.runtime/bot_heartbeat.json'),
        'user_consent':'No manual tasks; user permits interrupting current scheduled backfill, retaining cache, no success marker or proactive replay',
        'no_database_migration':True, 'recovery':'Versioned product files recoverable from base Git commit; preserve all private settings and ledger',
        'new_paid_usd':'0'})
    print('Preflight: tested source hashes, protected files and all ledger tables recorded.')

def protect():
    before = read(OUT/'preflight.json')
    assert all(sha(P/name) == digest for name,digest in before['protected'].items())
    actual = tables(LEDGER)
    assert actual == before['ledger'], {name:(value,actual.get(name)) for name,value in before['ledger'].items() if actual.get(name)!=value}
    save('protection-after.json', {'at':datetime.now(timezone.utc).isoformat(),
        'protected_files_unchanged':True,'all_ledger_tables_unchanged':True,'new_paid_usd':'0',
        'ledger':actual})
    print('Protected settings, old packs, all accounting tables and unknown reservations unchanged.')

def scan(data, is_zip=False):
    if is_zip:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for name in z.namelist():
                if not name.endswith('/'):
                    scan(z.read(name), name.endswith('.zip'))
    else:
        assert not re.search(rb'(?<![A-Za-z0-9])(?:sk-(?:proj-)?[A-Za-z0-9_-]{30,}|eyJ[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{20,}|[0-9]{8,12}:[A-Za-z0-9_-]{30,})',data), 'Possible secret in staged content'

def stage():
    assert not git('diff','--cached','--name-only',root=W)
    files = SOURCE + ['README.md']
    files += [(ROOT/name).relative_to(W).as_posix() for name in ['report.md','fixture-restore.json',
        'protection.json','helper-archive.json','offline-helpers.zip']]
    for folder in ['related-release','release-full','full-final']:
        for name in ['session.json','details.json','source-sha256.json']:
            if (ROOT/folder/name).exists():
                files.append((ROOT/folder/name).relative_to(W).as_posix())
    files += [p.relative_to(W).as_posix() for p in (ROOT/'release-replay').rglob('*.json')
        if 'logs' not in p.relative_to(ROOT/'release-replay').parts and 'blocked/change_packs' not in p.as_posix()]
    files += [p.relative_to(W).as_posix() for p in OUT.iterdir() if p.is_file() and p.name in {'preflight.json','old-pack-guard.json'}]
    for name in files:
        scan((W/name).read_bytes(),name.endswith('.zip'))
    subprocess.run(['git','add','--',*files],cwd=W,check=True)
    assert sorted(git('diff','--cached','--name-only',root=W).splitlines()) == sorted(files)
    subprocess.run(['git','diff','--cached','--check'],cwd=W,check=True)
    save('release-files.json',{'files':files,'secret_scan':'clear','only_this_task':True,
        'raw_sources_and_responses_retained_locally_not_copied_to_production':True})
    print('Staged exact allowlist:',len(files),'files; secret scan clear.')

def old_pack():
    sys.path.insert(0,str(P))
    from research_center import topic_apply_service as service
    from research_center.topic_models import TopicChangePack
    results = []
    for day in ['20261113_224616','20261117_234022']:
        original = read(P/f'data/topic/change_packs/change_{day}.json')
        assert original['extra']['evidence_review_complete'] is False
        guards = {name:Mock(side_effect=AssertionError('No topic writes')) for name in
            ['backup_topic_files','load_topic_profiles','save_topic_profiles','save_company_topic_map',
             'save_supply_chain_nodes','save_company_knowledge_data','update_change_pack_status','write_topic_audit_log']}
        with ExitStack() as stack:
            stack.enter_context(patch.object(service,'load_change_pack',return_value=TopicChangePack.from_dict(deepcopy(original))))
            for name,mock in guards.items():
                stack.enter_context(patch.object(service,name,mock))
            result = service.confirm_change_pack(original['change_id'],user_id='offline-deployment-guard')
        assert result.success is False and result.errors and all(mock.call_count==0 for mock in guards.values())
        results.append({'change_id':original['change_id'],'success':False,'errors':result.errors,'all_write_boundaries_zero':True})
    save('old-pack-guard.json',results)
    print('Both old topic packs blocked by native apply guard, zero writes.')

def startup():
    save('startup.json',{'at':datetime.now(timezone.utc).isoformat(),
        'consent':'User confirmed no manual tasks and permits interrupting scheduled backfill',
        'no_paid_tests':True,'no_proactive_backfill_replay':True,'old_topic_packs_not_applied':True})

def accept():
    import httpx
    protect()
    before = read(OUT/'preflight.json')
    assert all(sha(P/name)==digest for name,digest in before['source'].items())
    config = read(P/'config.json')
    checks = {}
    with httpx.Client(timeout=25) as client:
        for method in ['getMe','getMyCommands','getWebhookInfo']:
            try:
                response = client.get('https://api.telegram.org/bot'+config['api_token']+'/'+method)
            except httpx.TransportError as exc:
                raise RuntimeError('Read-only Telegram check: '+type(exc).__name__) from None
            assert response.status_code==200 and response.json()['ok']
            data = response.json()['result']
            if method == 'getMyCommands':
                assert {'research','value_scan','macro','theme','theme_flow','theme_radar','sector_strength','radar','news','topic_maintain'} <= {row['command'] for row in data}
                checks[method]={'ok':True,'count':len(data),'ten_ai_entries':True}
            elif method == 'getWebhookInfo':
                assert not data['url']
                checks[method]={'ok':True,'pending':data['pending_update_count']}
            else:
                assert data['is_bot']
                checks[method]={'ok':True}
    hb = read(P/'.runtime/bot_heartbeat.json')
    health = hb['schedule_health']
    poll = health['telegram_transport']['channels']['polling']
    cutoff = datetime.fromisoformat(read(OUT/'startup.json')['at'])
    assert datetime.fromisoformat(hb['updated_at'])>cutoff and hb['job_queue_available']
    assert hb['pid'] != before['heartbeat_before']['pid']
    assert poll['status']=='healthy' and datetime.fromisoformat(poll['last_success_at'])>cutoff
    assert health['queue_size']==0 and health['current_task'] is None
    assert health['etf_monitor']['status']=='READY' and datetime.fromisoformat(health['etf_monitor']['updated_at'])>cutoff
    save('runtime-acceptance.json',{'at':datetime.now(timezone.utc).isoformat(),'commit':git('rev-parse','HEAD'),
        'pid':hb['pid'],'heartbeat':hb['updated_at'],'native_poll_success':poll['last_success_at'],
        'queue':0,'current_task':None,'etf':'READY','telegram':checks,'new_paid_usd':'0',
        'original_ledger_and_unknown_reservations_unchanged':True,'old_topic_packs_not_applied':True,
        'native_next_paid_schedule_content_not_retested':True})
    save('heartbeat-after.json',hb)
    print('Original Telegram connection, native polling, command registration, idle queue and ETF READY accepted.')

def collect():
    source = P/'verification/topic-batch-evidence-20261119/deployment/main-regression'
    assert read(source/'session.json')['exit_status']==0
    assert read(source/'session.json')['source_unchanged']
    for name in ['session.json','source-sha256.json','details.json']:
        if (source/name).exists():
            target = OUT/'main-regression'/name
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes((source/name).read_bytes())
            assert sha(target)==sha(source/name)
    with zipfile.ZipFile(OUT/'deployment-helper.zip','w',zipfile.ZIP_DEFLATED) as z:
        z.write(Path(__file__),'deploy.py')
    print('Main regression copied exactly and deployment helper retained.')

def stage_docs():
    files = ['README.md',(ROOT/'report.md').relative_to(W).as_posix()]
    files += [p.relative_to(W).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='git-publication.json']
    staged = git('diff','--cached','--name-only',root=W).splitlines()
    assert set(staged) <= set(files)
    for name in files:
        scan((W/name).read_bytes(),name.endswith('.zip'))
    subprocess.run(['git','add','--',*files],cwd=W,check=True)
    expected = git('diff','HEAD','--name-only','--',*files,root=W).splitlines()
    assert sorted(git('diff','--cached','--name-only',root=W).splitlines())==sorted(expected)
    subprocess.run(['git','diff','--cached','--check'],cwd=W,check=True)
    print('Staged only this task documentation and deployment evidence:',len(files))

def merge_docs():
    assert not git('diff','--cached','--name-only')
    target = git('rev-parse','codex/ai-schedule-stability')
    changes = git('diff','--name-only','HEAD..'+target).splitlines()
    assert all(name=='README.md' or name.startswith('verification/topic-batch-evidence-20261119/') for name in changes)
    tracked = set(git('ls-files').splitlines())
    adopt = [name for name in changes if (P/name).is_file() and name not in tracked]
    for name in adopt:
        assert git('hash-object','--path',name,str(P/name))==git('rev-parse',target+':'+name), name
    if adopt:
        subprocess.run(['git','add','--',*adopt],cwd=P,check=True)
    subprocess.run(['git','merge','--ff-only','codex/ai-schedule-stability'],cwd=P,check=True)
    assert not git('diff','--cached','--name-only')
    print('Final docs/evidence merged, runtime files unchanged; no restart.')

def publish():
    protect()
    commit = git('rev-parse','HEAD')
    remote = git('ls-remote','origin','refs/heads/main').split()[0]
    assert commit==remote==git('rev-parse','HEAD',root=W)
    hb=read(P/'.runtime/bot_heartbeat.json')
    assert hb['pid']==read(OUT/'runtime-acceptance.json')['pid']
    allowed = set(read(OUT/'release-files.json')['files'])
    names = git('diff','--name-only',BASE+'..HEAD').splitlines()
    assert all(name in allowed or name.startswith('verification/topic-batch-evidence-20261119/deployment/') for name in names)
    save('git-publication.json',{'main':commit,'origin_main':remote,'matches':True,'pid':hb['pid'],
        'only_task_changes_committed':True,'restart_after_docs':False,'new_paid_usd':'0',
        'original_ledger_all_tables_unchanged':True,'old_topic_packs_not_applied':True})
    print('Published verified main == origin/main:',commit)

{'preflight':preflight,'protect':protect,'stage':stage,'old-pack':old_pack,'startup':startup,
 'accept':accept,'collect':collect,'stage-docs':stage_docs,'merge-docs':merge_docs,'publish':publish}[sys.argv[1]]()
