from datetime import datetime
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[3]
PRODUCTION = Path('D:/code/stock_ai_bot')
OUT = ROOT / 'verification/topic-batch-evidence-20261119'
ORIGINAL = ROOT / 'verification/topic-scheduled-live-20261119'
preflight = json.loads((ORIGINAL / 'preflight.json').read_text(encoding='utf-8-sig'))
saved_rows = json.loads((ORIGINAL / 'accounting.json').read_text(encoding='utf-8-sig'))
checks = {}
for group in ('protected_sha256', 'source_sha256'):
    checks[group] = {}
    for name, expected in preflight[group].items():
        actual = hashlib.sha256((PRODUCTION / name).read_bytes()).hexdigest()
        checks[group][name] = {'sha256': actual, 'unchanged': actual == expected}
        assert actual == expected, name

db = PRODUCTION / '.workdata/ai_budget/openai/openai-credits.sqlite3'
connection = sqlite3.connect(db.as_uri() + '?mode=ro', uri=True)
connection.row_factory = sqlite3.Row
try:
    current = [dict(row) for row in connection.execute(
        'SELECT * FROM requests WHERE round_id=? ORDER BY id', (preflight['round_id'],))]
    assert current == sorted(saved_rows, key=lambda row: row['id'])
    reservations = [dict(row) for row in connection.execute(
        "SELECT id,status,estimate,actual,purpose,round_id FROM requests "
        "WHERE status NOT IN ('success','failed','cancelled','released') ORDER BY id")]
    old_unknown = [row for row in reservations if row['id'] == '370572175b2f424f892c25746b82ea87']
    assert len(old_unknown) == 1
    assert Decimal(old_unknown[0]['estimate']) == Decimal('0.288884')
    assert old_unknown[0]['actual'] is None
finally:
    connection.close()

heartbeat = json.loads((PRODUCTION / '.runtime/bot_heartbeat.json').read_text(encoding='utf-8-sig'))
proof = {
    'checked_at': datetime.now().astimezone().isoformat(),
    'production_protection': checks,
    'ledger_read_only': True,
    'original_round_rows_identical': True,
    'original_round_request_count': len(current),
    'original_round_settled_usd': str(sum((Decimal(row['actual'] or '0') for row in current), Decimal('0'))),
    'original_round_all_development': all(row['purpose'] == 'development' for row in current),
    'existing_unsettled_entries_untouched': reservations,
    'known_old_unknown_reservation_preserved': old_unknown,
    'new_paid_calls': 0,
    'new_paid_usd': '0',
    'production_heartbeat_at_read': heartbeat,
    'production_restart': False,
    'production_deployment': False,
}
(OUT / 'protection.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k: proof[k] for k in ('checked_at', 'original_round_request_count',
    'original_round_settled_usd', 'original_round_all_development', 'new_paid_usd')}, ensure_ascii=False))
