"""Explicit, source-hash-pinned single evidence correction; no provider calls."""
from __future__ import annotations

from collections import Counter
from contextlib import ExitStack, closing
from copy import deepcopy
from dataclasses import replace
from datetime import date
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
from types import SimpleNamespace
from unittest.mock import patch

T = Path(__file__).resolve().parent
W = T.parents[2]
P = Path('D:/code/stock_ai_bot')
E = W/'verification/topic-scheduled-live-20261119'
OUT = W/'verification/topic-batch-evidence-20261119/release-replay'
BAD = 'Qcffee65a22f6ec5c4293f79'
GOOD = 'Qcffee65a22f6ec5c4293f79f'
THEME = 'agentic_ai_cpu_server_reconfiguration'
BODY_SHA = 'ca6ec2df1edbfecc8a2d753ee333125e9a8f9fd2815442970f14fede36163d0c'
sys.path.insert(0, str(W))
os.environ.update(TEMP=str(T), TMP=str(T), CODEX_TASK_TEST_ROOT=str(T/'cache'),
    STOCK_AI_BOT_WORKDATA_ROOT=str(T/'workdata'), STOCK_AI_BOT_WORKDATA_PROFILE='topic-offline-repair')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str),encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


NETWORK_ATTEMPTS = []
def refuse(*args, **kwargs):
    NETWORK_ATTEMPTS.append('blocked')
    raise AssertionError('Offline replay cannot access network or paid providers.')


import httpx
import requests
import urllib.request
httpx.Client.send = refuse
httpx.AsyncClient.send = refuse
requests.sessions.Session.request = refuse
urllib.request.urlopen = refuse

from research_center import topic_maintain_service as service
from research_center import topic_pipeline_service as pipeline
from research_center import topic_repository as repository
from research_center import data_services, web_fetch_enrichment, topic_evidence_extractor, prompt_logging
from research_center.topic_quote_binding import quote_catalog
from research_center.topic_input_package import merge_topic_sources, topic_stage_variables, expand_topic_stage_variables
from research_center.config import ResearchCenterConfig
from research_center.command_parser import parse_command_text
from research_center.deepseek_service import ai_task


INPUT = E/'logs/topic_inputs/change_20261119_222513.json'
RAW = E/'logs/topic_ai_raw/change_20261119_222513.json'
PACK = E/'change_packs/change_20261119_222513.json'
data = read(INPUT)
original = read(PACK)
stages = {s['stage']:s for s in read(RAW)['stages']}
source_rows = merge_topic_sources(data)
catalog = {s['quote_id']:s for s in quote_catalog(source_rows)}
assert BAD not in catalog and GOOD in catalog
span = catalog[GOOD]
assert span['source_id']=='S024' and span['body_sha256']==BODY_SHA
assert span['publish_date']=='2026-11-16'
assert '供給端瓶頸仍未解，HBM記憶體、先進封裝（CoWoS' in span['text']
assert '短期內仍難完全替代GPU供應鏈[4][5][6]。' in span['text']


def corrected_stage():
    payload = service._parse_ai_json_response(stages['detail_expand_2']['raw'])
    changed = deepcopy(payload)
    action = changed['actions'][0]
    assert action['theme_id']==THEME
    evidence = action['evidence'][1]
    assert evidence['quote_id']==BAD and evidence['source_id']=='S024'
    assert evidence['url']==span['url'] and evidence['publish_date']==span['publish_date']
    before = deepcopy(evidence)
    evidence['quote_id'] = GOOD
    evidence['supporting_quote'] = span['text']
    back = deepcopy(changed)
    back['actions'][0]['evidence'][1] = before
    assert back==payload, 'No other model content may be edited.'
    save(OUT/'correction-manifest.json', {'stage':'detail_expand_2','path':'/actions/0/evidence/1',
        'theme_id':THEME,'original':before,'replacement':deepcopy(evidence),
        'source_span':span,'policy':'Explicit agent-selected original span; no fuzzy matching or production validator changes.',
        'input_sha256':sha(INPUT),'raw_response_sha256':sha(RAW),'original_pack_sha256':sha(PACK),
        'new_paid_calls':0})
    save(OUT/'corrected-detail-expand-2.json',changed)
    return json.dumps(changed,ensure_ascii=False)


def replay(label, mode):
    target = OUT/label
    calls, roundtrips, progress, checkpoints = [], [], [], []
    cache = SimpleNamespace(cached=lambda *a:None, cache=lambda *a:None)
    class SavedClient:
        model='gpt-6-luna'
        timeout_seconds=600
        max_output_tokens=32768
        account=cache
        stage=None
        def for_stage(self, stage):
            self.stage=stage
            return self
        def ensure_ready(self):
            return None
        def is_configured(self):
            return True
        def with_output_limit(self, limit):
            return self
        def prompt_capacity(self, *a, **kw):
            return {'fits':True,'scope':'Original verified live batch layout only; no fresh provider capacity verification.'}
        def generate_json(self, prompt):
            current=list((target/'logs/topic_ai_raw').glob('*.json'))
            if calls:
                assert len(current)==1
                checkpoint=read(current[0])
                assert checkpoint['checkpoint']['not_final_package'] is True
                checkpoints.append({'before_stage':self.stage,
                    'recorded_responses':len(checkpoint['stages']),
                    'batch_statuses':[r['status'] for r in checkpoint['checkpoint']['batches']],
                    'not_final_package':True})
            if self.stage.endswith('_evidence_retry'):
                calls.append(self.stage)
                requests=json.loads(prompt.split('\n',1)[1])
                if mode=='recover':
                    selections=[]
                    for row in requests:
                        selected=[key for key,value in row['allowed_choices'].items() if value['quote_id']==GOOD]
                        assert len(selected)==1
                        selections.append({'path':row['path'],'quote_choice':selected[0]})
                    response={'repairs':selections}
                else:
                    response={'repairs':[]}
                selected_sources={s['source_id'] for row in requests for s in row['allowed_choices'].values()}
                assert selected_sources=={'S024'}
                save(target/'reselection-proof.json',{'prompt_chars':len(prompt),
                    'source_ids':sorted(selected_sources),'response_fixture':response,
                    'all_source_spans_present':{row['path']:len(row['allowed_choices'])==2 for row in requests},
                    'new_model_call':False,'fixture_only':True})
                return SimpleNamespace(raw=json.dumps(response,ensure_ascii=False),
                    diagnostics={'actual_model':'offline-reselection-fixture','offline_replayed':True,'new_paid_call':False})
            native_calls=[s for s in calls if not s.endswith('_evidence_retry')]
            stage = list(stages)[len(native_calls)]
            assert self.stage==stage, 'Response must belong to its original pipeline stage.'
            calls.append(stage)
            text = stages[stage]['raw']
            return SimpleNamespace(raw=text,diagnostics={**stages[stage].get('diagnostics',{}),
                'offline_replayed':True,'new_paid_call':False})
    client = SavedClient()
    from research_center.models import SourceItem
    discovery = [SourceItem(**s) for s in data['discovery_sources']]
    base = [SourceItem(**s) for s in data.get('base_sources',[])]
    center = SimpleNamespace(config=ResearchCenterConfig(deepseek_only=True,openai_primary_enabled=True,
        enable_low_model_digest=True),deepseek=client,deepseek_organizer=client,low_model_minimax=client,
        _gemini_discovery_runner=SimpleNamespace(run_discovery_flow=lambda *a,**kw:(deepcopy(discovery),{})))
    original_variables = topic_stage_variables
    def checked_variables(*a,**kw):
        variables = original_variables(*a,**kw)
        generated = original_variables(a[0], {}, *a[2:], **kw)
        decoded = expand_topic_stage_variables({k:variables[k] for k in generated})
        selected = decoded.get('web_fetched_sources_json') or decoded.get('discovery_sources_json') or []
        expected = {r['source_id']:r for r in source_rows}
        assert all(s==expected[s['source_id']] for s in selected)
        roundtrips.append({'source_count':len(selected),'all_fields_and_body_equal':True})
        return variables
    def fixed_layout(candidates,*a,**kw):
        indexed = {r['theme_id']:r for r in candidates}
        layout = [[indexed[t] for t in batch['candidate_ids']] for batch in original['extra']['detail_review']['batches']]
        assert {r['theme_id'] for batch in layout for r in batch}==set(indexed)
        return layout
    from research_center.analysis_followup_service import AnalysisFollowupStore
    from research_center import date_aware_context
    with ExitStack() as stack:
        changes = [
            (data_services,'collect_structured_data',lambda *a,**kw:(deepcopy(data),deepcopy(base))),
            (date_aware_context,'filter_and_sort_sources_for_analysis_date',lambda sources,request:(sources,[])),
            (web_fetch_enrichment,'_enrich_sources_with_web_fetch',lambda *a,**kw:None),
            (topic_evidence_extractor,'build_topic_evidence_candidates',lambda *a,**kw:deepcopy(data['webfetch_evidence'])),
            (service,'is_formal_library_empty',lambda:False),
            (service,'load_company_knowledge_data',lambda:deepcopy(data.get('company_knowledge',{}))),
            (service,'load_topic_profiles',lambda:deepcopy(data.get('existing_topic_profiles',[]))),
            (service,'run_low_model_digest_for_payload',lambda *a,**kw:deepcopy(data.get('low_model_digest',{}))),
            (service,'_topic_stage_client',lambda center,stage,size:client.for_stage(stage)),
            (pipeline,'_full_evidence_detail_batches',fixed_layout),
            (pipeline,'topic_stage_variables',checked_variables),
            (prompt_logging,'PROMPT_LOG_DIR',target/'logs/ai_prompts'),
            (repository,'_CHANGE_PACK_DIR',target/'change_packs'),
            (repository,'_AUDIT_DIR',target/'audit_logs'),
            (repository,'_PROMPT_LOG_DIR',target/'logs/ai_prompts'),
            (repository,'_RAW_RESP_DIR',target/'logs/topic_ai_raw'),
            (repository,'_BACKUP_DIR',T/'unused-backups'),
            (AnalysisFollowupStore,'pending',lambda *a,**kw:[]),
        ]
        for mod,key,value in changes:
            stack.enter_context(patch.object(mod,key,value))
        request = replace(parse_command_text('/topic_maintain --deep'),report_date=date(2026,11,19))
        with ai_task('topic_maintain',background=True,report_date='2026-11-19'):
            pack = service.run_topic_maintain(request,center,progress=lambda m:progress.append(m))
        assert [s for s in calls if not s.endswith('_evidence_retry')]==list(stages), (calls,list(stages))
        assert [s for s in calls if s.endswith('_evidence_retry')]==['detail_expand_2_evidence_retry'], calls
        assert pack.extra['detail_review']['ai_completed_count']==8 and len(pack.actions)==8
        pack.extra['offline_repair_provenance']={'source_change_id':original['change_id'],
            'method':'Saved live inputs and original responses through native maintenance pipeline',
            'reselection_response_fixture':mode,'manual_model_output_edit':False,'new_paid_calls':0,'network_attempts':0,
            'not_a_new_live_success':True,'auto_applied':False}
        repository.save_change_pack(pack)
    save(target/'replay.json',{'calls_reused':calls,'roundtrips':roundtrips,'progress':progress,
        'intermediate_checkpoints':checkpoints,
        'change_id':pack.change_id,'citation_count':pack.extra['citation_audit']['citation_count'],
        'issues':pack.extra['citation_audit']['issues'],'evidence_complete':pack.extra['evidence_review_complete'],
        'action_complete':pack.extra['action_review_complete'],'ai_complete':pack.extra['ai_review_complete']})
    return pack


def main():
    owner = read(T/'.codex-task.json')
    assert Path(owner['project'])==W
    assert not OUT.exists(), 'Do not overwrite an existing repair evidence set.'
    originals = {str(p):sha(p) for p in (INPUT,RAW,PACK)}
    baseline = replay('blocked','refuse')
    assert not baseline.extra['evidence_review_complete']
    assert any(s.get('quote_id')==BAD for s in baseline.extra['citation_audit']['issues'])
    fixed = replay('recovered','recover')
    assert all(fixed.extra[k] is True for k in ('ai_review_complete','evidence_review_complete','action_review_complete'))
    assert fixed.extra['citation_audit']['blocking_count']==0
    assert fixed.extra['citation_audit']['citation_count']==74
    for label in ('blocked','recovered'):
        saved=read(next((OUT/label/'logs/topic_ai_raw').glob('*.json')))
        assert len(saved['checkpoint']['batches'])==4
        statuses=[r['status'] for r in saved['checkpoint']['batches']]
        assert statuses==(['validated']*4 if label=='recovered' else ['validated','pending','validated','validated'])
    unchanged = []
    for index,(before,after) in enumerate(zip(baseline.actions,fixed.actions,strict=True)):
        if index!=2:
            assert before.to_dict()==after.to_dict(), index
            unchanged.append(before.theme_id)
    prior=read(E/'offline-repair/verified/repaired/change_packs/change_20261119_225654.json')
    assert [a.to_dict() for a in fixed.actions]==prior['actions']
    assert baseline.extra['deferred_candidates']==fixed.extra['deferred_candidates']
    assert baseline.company_knowledge_updates==fixed.company_knowledge_updates
    assert all(sha(Path(p))==h for p,h in originals.items())
    assert not NETWORK_ATTEMPTS
    save(OUT/'verification.json',{'status':'offline_repair_passed','originals_unchanged':originals,
        'baseline_blockers':baseline.extra['citation_audit']['blocking_count'],'repaired_blockers':0,'themes':8,'citation_count':74,
        'other_seven_actions_identical':unchanged,'deferred_candidates_unchanged':True,
        'company_knowledge_updates_unchanged':True,'network_attempts':0,'new_paid_calls':0,
        'equal_to_explicit_source_verified_repair':True,
        'repaired_change_id':fixed.change_id,'repaired_path':str(OUT/'recovered/change_packs'/f'{fixed.change_id}.json')})
    print(json.dumps(read(OUT/'verification.json'),ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
