from pathlib import Path
from zipfile import ZipFile
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
FORMAL = Path('D:/code/stock_ai_bot')
DEV = FORMAL / '.worktrees/terra-xhigh'
OUT = ROOT / 'verification/topic-batch-evidence-20261119'
marker = json.loads((WORK/'.codex-task.json').read_text(encoding='utf-8'))
assert Path(marker['project']) == ROOT
manifest = DEV/'verification/terra-xhigh/fixtures-retest/fixture-restore.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == '41de4957215f92b024f1421f02b12380f43471bcc9b456a50697fb2cf4dc7965'
rows = json.loads(manifest.read_text(encoding='utf-8'))
count = total = 0

def store(path, data, sha):
    global count, total
    assert path.resolve().is_relative_to(WORK) and hashlib.sha256(data).hexdigest() == sha
    if path.exists():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == sha
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(data)
    count += 1
    total += len(data)

with ZipFile('E:/stock_ai_cleanup_archive/stock_ai_cleanup_archive_20261020.zip') as z:
    for row in rows:
        relative = Path(row['relative'])
        assert not relative.is_absolute() and '..' not in relative.parts
        data = z.read('D_workdata/'+relative.as_posix())
        assert len(data) == row['bytes']
        store(WORK/'workdata'/relative, data, row['sha256'])
causal = json.loads((DEV/'verification/terra-xhigh/fixtures-retest/causal-cache-restore.json').read_text(encoding='utf-8'))
assert hashlib.sha256(Path(causal['archive']).read_bytes()).hexdigest() == causal['archive_sha256']
with ZipFile(causal['archive']) as z:
    names = [n for n in z.namelist() if Path(n).name == causal['file']]
    assert len(names) == 1
    store(WORK/causal['file'], z.read(names[0]), causal['sha256'])
proof = {'files':count,'bytes':total,'all_file_sha256_verified':True,'formal_files_modified':False}
(OUT/'fixture-restore.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
print(proof)
