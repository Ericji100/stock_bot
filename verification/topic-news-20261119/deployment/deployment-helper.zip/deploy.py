"""Scoped deployment; no paid requests, immutable production evidence checks."""
from pathlib import Path
from contextlib import closing,ExitStack
from datetime import datetime,timezone
import hashlib
import io
import json
import re
import sqlite3
import subprocess
import sys
import zipfile

W=Path('D:/code/_codex_worktrees/ai-schedule-stability/stock_ai_bot')
P=Path('D:/code/stock_ai_bot')
OUT=W/'verification/topic-news-20261119/deployment';OUT.mkdir(parents=True,exist_ok=True)
BASE='4e03f93158ab2c7b8dd5534410a8f8c045c92725'
PY=P/'.venv/Scripts/python.exe'
MANAGER=Path('D:/workspace/projects/infrastructure/system_management/scripts/codex_backup_manager.py')
SOURCE=['main.py','research_center/news_repository.py','research_center/news_service.py',
    'research_center/scheduled_outcome_notice.py','research_center/topic_citation_audit.py',
    'research_center/topic_input_package.py','research_center/topic_maintain_service.py',
    'research_center/topic_models.py','research_center/topic_pipeline_service.py',
    'research_center/topic_schema_normalizer.py','research_center/topic_quote_binding.py',
    'tests/test_news_schedule_balance.py','tests/test_topic_input_package.py','tests/test_topic_pipeline_service.py',
    'tests/test_topic_news_recovery_1119.py']
PROTECTED=['.gitignore','config.json','config/secrets.json','config/research_center.json',
    'config/company_theme_map.json','config/supply_chain_nodes.json','config/theme_profiles.json','stock_list.json']
for day in ['20261113_224616','20261117_234022']:
    PROTECTED += [f'logs/topic_inputs/change_{day}.json',f'logs/topic_ai_raw/change_{day}.json',f'data/topic/change_packs/change_{day}.json']
NEWS=P/'.workdata/prod/database/stock_research.db'
LEDGER=P/'.workdata/ai_budget/openai/openai-credits.sqlite3'
OUTCOMES=P/'.workdata/prod/runtime/schedule_outcomes/outcomes.sqlite3'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def save(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def git(*args,root=P):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def tables(path):
    with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)) as c:
        c.execute('BEGIN');result={}
        for (name,) in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
            rows=c.execute('SELECT * FROM "'+name+'" ORDER BY rowid').fetchall()
            result[name]={'rows':len(rows),'sha256':hashlib.sha256(json.dumps(rows,ensure_ascii=False).encode()).hexdigest()}
        return result


def preflight():
    assert git('rev-parse','HEAD')==git('rev-parse','HEAD',root=W)==BASE
    assert not git('diff','--cached','--name-only') and not git('diff','--cached','--name-only',root=W)
    hashes=read(W/'verification/topic-news-20261119/release-full/source-sha256.json')
    assert all(sha(W/name)==value for name,value in hashes.items())
    assert read(W/'verification/topic-news-20261119/release-full/session.json')['exit_status']==0
    save('preflight.json',{'at':datetime.now(timezone.utc).isoformat(),'base':BASE,'source':{name:sha(W/name) for name in SOURCE},
        'protected':{name:sha(P/name) for name in PROTECTED},'ledger':tables(LEDGER),'news':tables(NEWS),'outcomes':tables(OUTCOMES),
        'formal_dirty':git('status','--short','--untracked-files=no'),'tested_files':len(hashes),
        'user_consent':'No running manual tasks; user permits start after verification; old topic packs remain blocked',
        'new_paid_usd':'0','bot_was_stopped':True})
    print('627 tested file hashes and production data/accounting captured; no code changes since full suite.')


def backups():
    receipts=[]
    for path in [NEWS,OUTCOMES]:
        assert not Path(str(path)+'-wal').exists() or not Path(str(path)+'-wal').stat().st_size
        result=json.loads(subprocess.check_output([str(PY),'-B',str(MANAGER),'create','--source',str(path),
            '--session','ds','--task','topic-news-deploy-1119','--reason','Recoverable news journal schema and interrupted outcome deployment'],cwd=P,text=True,encoding='utf-8'))
        receipts.append(result)
        save('backup-creation.json',receipts)
        copy=Path(result['entry']['path'])
        assert sha(copy)==sha(path) and tables(copy)==tables(path)
        with closing(sqlite3.connect(copy.as_uri()+'?mode=ro',uri=True)) as c:assert c.execute('PRAGMA integrity_check').fetchall()==[('ok',)]
    print('Two managed pre-migration backups created, byte/content hashes and SQLite integrity verified.')


def protect():
    before=read(OUT/'preflight.json')
    assert all(sha(P/name)==value for name,value in before['protected'].items())
    assert tables(LEDGER)==before['ledger']
    assert all(sha(P/name)==value for name,value in before['source'].items())
    actual=tables(NEWS)
    assert all(actual.get(name)==value for name,value in before['news'].items())
    print('Original code/config/topic data, all cost rows and every pre-existing news table preserved.')


def stage():
    assert not git('diff','--cached','--name-only',root=W)
    root=W/'verification/topic-news-20261119'
    files=SOURCE+['README.md']+[p.relative_to(W).as_posix() for p in root.iterdir() if p.is_file()]
    for folder in ['first','related-final','related-final-pass','release-full']:
        for name in ['session.json','details.json','source-sha256.json']:
            if (root/folder/name).is_file():files.append((root/folder/name).relative_to(W).as_posix())
    def scan(data,is_zip):
        if is_zip:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for name in z.namelist():
                    if not name.endswith('/'):scan(z.read(name),name.endswith('.zip'))
        else:assert not re.search(rb'(?<![A-Za-z0-9])(?:sk-(?:proj-)?[A-Za-z0-9_-]{30,}|eyJ[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{20,}|[0-9]{8,12}:[A-Za-z0-9_-]{30,})',data),'Possible secret in staged content'
    for name in files:scan((W/name).read_bytes(),name.endswith('.zip'))
    subprocess.run(['git','add','--',*files],cwd=W,check=True)
    assert sorted(git('diff','--cached','--name-only',root=W).splitlines())==sorted(files)
    subprocess.run(['git','diff','--cached','--check'],cwd=W,check=True)
    save('release-files.json',{'files':files,'secret_scan':'clear'})
    print('Staged only',len(files),'task files; exact allowlist and secret scan passed.')


def old_pack():
    from unittest.mock import patch,Mock
    from copy import deepcopy
    sys.path.insert(0,str(P))
    from research_center import topic_apply_service as service
    from research_center.topic_models import TopicChangePack
    original=read(P/'data/topic/change_packs/change_20261117_234022.json')
    assert original['extra']['evidence_review_complete'] is False
    guards={name:Mock(side_effect=AssertionError('No topic writes')) for name in
        ['backup_topic_files','load_topic_profiles','save_topic_profiles','save_company_topic_map','save_supply_chain_nodes',
         'save_company_knowledge_data','update_change_pack_status','write_topic_audit_log']}
    with ExitStack() as stack:
        stack.enter_context(patch.object(service,'load_change_pack',return_value=TopicChangePack.from_dict(deepcopy(original))))
        for name,mock in guards.items():stack.enter_context(patch.object(service,name,mock))
        result=service.confirm_change_pack(original['change_id'],user_id='offline-deployment-guard')
    assert result.success is False and any('不可套用' in str(e) for e in result.errors)
    assert all(mock.call_count==0 for mock in guards.values())
    save('old-pack-guard.json',{'success':False,'errors':result.errors,'all_write_and_backup_boundaries_zero':True,'formal_pack_untouched':True})
    print('Old topic pack refused by actual guard before all write boundaries.')


def accept():
    import httpx
    protect();before=read(OUT/'preflight.json');config=read(P/'config.json');checks={}
    with httpx.Client(timeout=25) as client:
        for method in ['getMe','getMyCommands','getWebhookInfo']:
            try:response=client.get('https://api.telegram.org/bot'+config['api_token']+'/'+method)
            except httpx.TransportError as e:raise RuntimeError('Readonly Telegram check '+type(e).__name__) from None
            assert response.status_code==200 and response.json()['ok']
            data=response.json()['result']
            if method=='getMyCommands':
                assert {'research','value_scan','macro','theme','theme_flow','theme_radar','sector_strength','radar','news','topic_maintain'} <= {r['command'] for r in data}
                checks[method]={'ok':True,'count':len(data),'ten_ai_entries':True}
            elif method=='getWebhookInfo':assert not data['url'];checks[method]={'ok':True,'pending':data['pending_update_count']}
            else:assert data['is_bot'];checks[method]={'ok':True}
    hb=read(P/'.runtime/bot_heartbeat.json');health=hb['schedule_health'];poll=health['telegram_transport']['channels']['polling']
    cutoff=datetime.fromisoformat(read(OUT/'startup.json')['at'])
    assert datetime.fromisoformat(hb['updated_at'])>cutoff and hb['job_queue_available']
    assert poll['status']=='healthy' and datetime.fromisoformat(poll['last_success_at'])>cutoff
    assert health['queue_size']==0 and health['current_task'] is None
    assert health['etf_monitor']['status']=='READY' and datetime.fromisoformat(health['etf_monitor']['updated_at'])>cutoff
    assert tables(LEDGER)==before['ledger']
    with closing(sqlite3.connect(NEWS.as_uri()+'?mode=ro',uri=True)) as c:
        run=c.execute('SELECT day,phase,status FROM news_refresh_runs WHERE run_id=?',('7dbc561d627e460c81b7fd402c90c8a9',)).fetchone()
        assert run==('2026-11-18','search','interrupted')
    with closing(sqlite3.connect(OUTCOMES.as_uri()+'?mode=ro',uri=True)) as c:
        outcome=c.execute('SELECT detail FROM outcomes WHERE run_id=?',('7dbc561d627e460c81b7fd402c90c8a9',)).fetchone()
        delivery=c.execute("SELECT state FROM deliveries WHERE command='news' AND day='2026-11-18'").fetchone()
        assert outcome and json.loads(outcome[0])['status']=='interrupted' and delivery and delivery[0]=='sent'
        for table in ['outcomes','deliveries']:
            old=c.execute('SELECT * FROM '+table+" WHERE NOT (command='news' AND day='2026-11-18') ORDER BY rowid").fetchall()
            assert {'rows':len(old),'sha256':hashlib.sha256(json.dumps(old,ensure_ascii=False).encode()).hexdigest()}==before['outcomes'][table]
    save('runtime-acceptance.json',{'at':datetime.now(timezone.utc).isoformat(),'commit':git('rev-parse','HEAD'),
        'pid':hb['pid'],'heartbeat':hb['updated_at'],'native_poll_success':poll['last_success_at'],'queue':0,
        'etf':'READY','telegram':checks,'legacy_news_run':run,'recovery_notice_delivery':delivery[0],
        'all_accounting_and_old_news_content_unchanged':True,'old_topic_not_applied':True,'new_paid_usd':'0',
        'business_ai_replay_sent':False,'native_next_schedules_observation_only':True})
    save('heartbeat-after.json',hb)
    print('Fresh polling, 43 commands, idle queue, ETF ready, one original recovery notice and original accounting accepted.')


def startup():
    save('startup.json',{'at':datetime.now(timezone.utc).isoformat(),'permission':'User confirmed no manual tasks and allowed start',
        'no_paid_tests':True,'legacy_source_recovery_notice_only':True})


def collect():
    folder=P/'verification/topic-news-20261119/deployment/main-regression'
    result=read(folder/'session.json')
    assert result['exit_status']==0 and result['source_unchanged']
    for name in ['session.json','source-sha256.json','details.json']:
        if (folder/name).is_file():
            target=OUT/'main-regression'/name;target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes((folder/name).read_bytes())
            assert sha(target)==sha(folder/name)
    with zipfile.ZipFile(OUT/'deployment-helper.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
        archive.write(Path(__file__),'deploy.py')
    print('Main regression evidence byte-verified and deployment helper archived.')


def prepare_backups():
    assert read(OUT/'runtime-acceptance.json')['recovery_notice_delivery']=='sent'
    before=read(OUT/'preflight.json');prepared=[]
    for backup in read(OUT/'backup-creation.json'):
        entry=backup['entry'];copy=Path(entry['path']);source=Path(entry['source'])
        expected=before['news'] if source==NEWS else before['outcomes']
        assert tables(copy)==expected and sha(copy)==entry['sha256']
        with closing(sqlite3.connect(copy.as_uri()+'?mode=ro',uri=True)) as c:assert c.execute('PRAGMA integrity_check').fetchall()==[('ok',)]
        proof={'passed':True,'source_sha256':sha(source),'backup_sha256':sha(copy),'checks':[
            {'name':'Original snapshot recoverable and all SQLite rows equal pre-deployment baseline','passed':True},
            {'name':'Backup SQLite integrity check returned ok','passed':True},
            {'name':'Native startup recovery, Telegram polling and no new paid calls accepted','passed':True}],
            'limits':'Original database before additive journal/outcome update; retain recovery baseline; not an automatic restore authorization'}
        folder=P/'verification/topic-news-20261119/deployment';folder.mkdir(parents=True,exist_ok=True)
        path=folder/(entry['id']+'-backup-proof.json');path.write_text(json.dumps(proof,indent=2),encoding='utf-8')
        (OUT/path.name).write_bytes(path.read_bytes())
        result=json.loads(subprocess.check_output([str(PY),'-B',str(P/'tools/prepare_backup_acceptance.py'),
            '--project',str(P),'--backup-id',entry['id'],'--verification-json',str(path),
            '--reference-file',str(P/'main.py'),'--reference-file',str(P/'research_center/news_repository.py'),
            '--reason','Verified journal deployment; original database recovery baseline retained'],cwd=P,text=True,encoding='utf-8'))
        assert sha(Path(result['record']))==result['sha256']
        record=read(Path(result['record']));checked=record['entries'][0]
        assert checked['id']==entry['id'] and checked['path']==entry['path'] and checked['source']==entry['source']
        assert checked['sha256']==entry['sha256'] and checked['recovery_required'] is True
        acceptance=read(Path(result['acceptance']))
        assert acceptance['passed'] and all(r['passed'] for r in acceptance['checks'])
        prepared.append(result)
    save('backup-completion-prepared.json',prepared)
    print(json.dumps(prepared,indent=2))


def stage_docs():
    collect()
    assert not git('diff','--cached','--name-only',root=W)
    files=['README.md','verification/topic-news-20261119/report.md']
    files += [p.relative_to(W).as_posix() for p in OUT.rglob('*') if p.is_file() and p.name!='git-publication.json']
    def scan(data,is_zip):
        if is_zip:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for name in z.namelist():
                    if not name.endswith('/'):scan(z.read(name),name.endswith('.zip'))
        else:assert not re.search(rb'(?<![A-Za-z0-9])(?:sk-(?:proj-)?[A-Za-z0-9_-]{30,}|eyJ[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{20,}|[0-9]{8,12}:[A-Za-z0-9_-]{30,})',data),'Possible secret'
    for name in files:scan((W/name).read_bytes(),name.endswith('.zip'))
    subprocess.run(['git','add','--',*files],cwd=W,check=True)
    assert sorted(git('diff','--cached','--name-only',root=W).splitlines())==sorted(files)
    subprocess.run(['git','diff','--cached','--check'],cwd=W,check=True)
    print('Only documentation and',len(files)-2,'deployment evidence files staged; no runtime code changed.')


def merge_docs():
    assert not git('diff','--cached','--name-only')
    target=git('rev-parse','codex/ai-schedule-stability')
    changes=git('diff','--name-only','HEAD..'+target).splitlines()
    assert all(name=='README.md' or name.startswith('verification/topic-news-20261119/') for name in changes)
    tracked=set(git('ls-files').splitlines())
    adopt=[name for name in changes if (P/name).is_file() and name not in tracked]
    for name in adopt:assert git('hash-object','--path',name,str(P/name))==git('rev-parse',target+':'+name),name
    if adopt:subprocess.run(['git','add','--',*adopt],cwd=P,check=True)
    subprocess.run(['git','merge','--ff-only','codex/ai-schedule-stability'],cwd=P,check=True)
    assert not git('diff','--cached','--name-only')
    print('Merged only final evidence/docs, adopted',len(adopt),'identical local evidence files, no restart.')


def publish():
    protect()
    local=git('rev-parse','HEAD');remote=git('ls-remote','origin','refs/heads/main').split()[0]
    assert local==remote
    hb=read(P/'.runtime/bot_heartbeat.json')
    assert hb['pid']==read(OUT/'runtime-acceptance.json')['pid']
    save('git-publication.json',{'main':local,'origin_main':remote,'matches':True,'pid':hb['pid'],
        'only_task_changes_committed':True,'restart_after_docs':False,'new_paid_usd':'0',
        'original_ledger_all_tables_unchanged':True,'old_topic_pack_not_applied':True})
    print('main == origin/main:',local)


{'preflight':preflight,'backups':backups,'stage':stage,'protect':protect,'old-pack':old_pack,'accept':accept,'startup':startup,'collect':collect,'prepare-backups':prepare_backups,'stage-docs':stage_docs,'merge-docs':merge_docs,'publish':publish}[sys.argv[1]]()
