from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[3]
DEV=Path('D:/code/stock_ai_bot/.worktrees/terra-xhigh')
sys.path.insert(0,str(ROOT))
import pytest
from tools import run_ai_offline_tests

class SavedEvidence:
    def pytest_runtest_setup(self,item):
        if item.nodeid=='tests/test_terra_focused_validation.py::test_saved_value_packet_preserves_core_and_already_retrieved_official_records':
            from tools import terra_focused_validation as module
            self.before=module.ROOT
            module.ROOT=DEV
    def pytest_runtest_teardown(self,item):
        if item.nodeid=='tests/test_terra_focused_validation.py::test_saved_value_packet_preserves_core_and_already_retrieved_official_records':
            from tools import terra_focused_validation as module
            module.ROOT=self.before

native=pytest.main
pytest.main=lambda args,plugins:native(args,plugins=[*plugins,SavedEvidence()])
raise SystemExit(run_ai_offline_tests.main())
