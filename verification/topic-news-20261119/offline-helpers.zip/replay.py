"""Frozen November 16-18 evidence replay, no HTTP, no production writers."""
from pathlib import Path
from contextlib import closing
from copy import deepcopy
from datetime import datetime, date
from dataclasses import asdict
from collections import Counter
import hashlib
import json
import os
import re
import sqlite3
import sys
import uuid
from unittest.mock import patch

W=Path(__file__).resolve().parents[3];WORK=Path(__file__).resolve().parent;P=Path('D:/code/stock_ai_bot')
OUT=W/'verification/topic-news-20261119';OUT.mkdir(parents=True,exist_ok=True)
REPLAY=WORK/('replay-'+uuid.uuid4().hex[:8]);REPLAY.mkdir()
assert Path(json.loads((WORK/'.codex-task.json').read_text())['project'])==W
os.environ.update(TEMP=str(WORK),TMP=str(WORK),STOCK_AI_BOT_WORKDATA_ROOT=str(WORK/'workdata'),
    CODEX_TASK_TEST_ROOT=str(WORK/'t'),DEEPSEEK_BUDGET_TEST_ROOT=str(WORK/'b'),
    OPENAI_API_KEY='',OPENAI_SECONDARY_API_KEY='',DEEPSEEK_API_KEY='offline-placeholder')
sys.path.insert(0,str(W))
import httpx,requests,urllib.request
def denied(*a,**kw):raise AssertionError('No external HTTP or paid request in saved-data replay')
httpx.Client.send=denied;httpx.AsyncClient.send=denied
requests.sessions.Session.request=denied;urllib.request.urlopen=denied

def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def save(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def rows(db,query,args=()):
    with closing(sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)) as conn:
        conn.row_factory=sqlite3.Row
        return [dict(row) for row in conn.execute(query,args)]


def topic():
    from research_center.topic_pipeline_service import run_topic_pipeline
    from research_center.topic_models import TopicChangeMode
    from research_center.topic_maintain_service import _load_prompt,_render_prompt,_parse_ai_json_response
    from research_center.topic_citation_audit import restore_topic_source_quotes,quarantine_topic_source_leads,quarantine_unproven_company_claims,audit_topic_citations
    from research_center.topic_input_package import merge_topic_sources,topic_stage_variables,expand_topic_stage_variables
    from research_center.topic_quote_binding import quote_catalog,topic_repair_plan
    from research_center.topic_apply_service import resolve_action_targets,coalesce_topic_updates,validate_action_targets
    from research_center.deepseek_service import ai_task
    original=read(P/'data/topic/change_packs/change_20261117_234022.json')
    data=read(P/'logs/topic_inputs/change_20261117_234022.json')
    raw=read(P/'logs/topic_ai_raw/change_20261117_234022.json')
    stages={r['stage']:r for r in raw['stages']};calls=[];prompts=[];roundtrips=[]
    def checked_variables(*args,**kwargs):
        variables=topic_stage_variables(*args,**kwargs)
        expanded=expand_topic_stage_variables(variables)
        actual=expanded.get('web_fetched_sources_json') or expanded.get('discovery_sources_json') or []
        expected={r['source_id']:r for r in merge_topic_sources(args[0])}
        assert all(row==expected[row['source_id']] for row in actual)
        roundtrips.append({'stage':'detail' if len(args)>2 and args[2] is not None else 'candidate',
            'source_count':len(actual),'all_fields_and_body_exactly_reconstructed':True})
        return variables
    def reuse(prompt,stage):
        assert stage in stages
        calls.append(stage);prompts.append({'stage':stage,'chars':len(prompt),'sent':False})
        folder=WORK/'prompts';folder.mkdir(exist_ok=True)
        (folder/(stage+'.md')).write_text(prompt,encoding='utf-8')
        return _parse_ai_json_response(stages[stage]['raw'])
    def layout(candidates,*a,**kw):
        indexed={r['theme_id']:r for r in candidates}
        batches=[[indexed[ref] for ref in row['candidate_ids']] for row in original['extra']['detail_review']['batches']]
        assert {r['theme_id'] for batch in batches for r in batch}==set(indexed)
        return batches
    with ai_task('topic_maintain',background=True,report_date='2026-11-17'),patch('research_center.topic_pipeline_service._full_evidence_detail_batches',side_effect=layout),patch('research_center.topic_pipeline_service.topic_stage_variables',side_effect=checked_variables):
        pack,logs=run_topic_pipeline(mode=TopicChangeMode.UPDATE,ai_model='gpt-6-luna',change_id='offline-1119-replay',
            iso_ts=original['created_at'],structured_data=deepcopy(data),prompt_variables={'mode':'update','report_date':'2026-11-17'},
            load_prompt=_load_prompt,render_prompt=_render_prompt,call_ai_json=reuse,require_full_ai=True,
            prompt_capacity=lambda *a,**kw:{'fits':True,'scope':'Frozen original response layout; no new capacity API or model run'})
    profiles=data.get('existing_topic_profiles') or []
    resolve_action_targets(pack,profiles);coalesce_topic_updates(pack,profiles)
    restore_topic_source_quotes(pack,data);quarantine_topic_source_leads(pack,data);quarantine_unproven_company_claims(pack,data)
    audit=audit_topic_citations(pack,data);targets=validate_action_targets(pack,profiles)
    plan=topic_repair_plan(pack,audit)
    pack.extra.update(citation_audit=audit,citation_repair_plan=plan,action_target_audit=targets,
        evidence_review_complete=audit['passed'],ai_status='ai_success' if audit['passed'] else 'partial_success')
    assert calls==list(stages) and len(pack.actions)==8 and pack.extra['detail_review']['ai_completed_count']==8
    assert targets['passed']
    sources=merge_topic_sources(data);catalog=quote_catalog(sources)
    for s in sources:
        from research_center.source_text_cleaner import source_body_text
        assert ''.join(row['text'] for row in catalog if row['source_id']==s['source_id'])==source_body_text(s)
    assert any('緯穎' not in row['quote'] and row['matched'] is False for row in audit['quote_checks'] if 'AI伺服器商機持續爆發' in row['quote'])
    assert not any(r['reason']=='supporting_quote_too_short' for r in audit['issues'])
    assert not audit['passed'] # Historical model paraphrase must not be declared verified.
    save('topic-replayed-pack.json',pack.to_dict())
    save('topic-replay.json',{'original_blockers':original['extra']['citation_audit']['blocking_count'],
        'remaining_blockers':audit['blocking_count'],'issues':audit['issues'],'actions':plan,'model_stages_reused':calls,
        'selected':8,'ai_completed':8,'unique_sources':len(sources),'quote_spans':len(catalog),
        'all_source_body_characters_preserved':True,'short_quote_restorations':pack.extra.get('source_quote_restorations'),
        'reference_bindings':pack.extra.get('quote_binding_audit'),'prompts':prompts,'input_roundtrip_checks':roundtrips,
        'new_paid_calls':0,'whole_pack_applicable':False,'new_prompt_model_compliance_verified':False,
        'capacity':'Original saved layout reused with capacity response stub; production checks unchanged'})
    print('Topic replay:',audit['blocking_count'],'blockers remain, only unsupported historical assertions; all 8 themes retained')


def news():
    from research_center.news_models import NewsItem
    from research_center.news_repository import NewsRepository
    from research_center import news_service as service
    from research_center.topic_maintain_service import _parse_ai_json_response
    from research_center.deepseek_service import ai_task
    db=P/'.workdata/prod/database/stock_research.db';ledger=P/'.workdata/ai_budget/openai/openai-credits.sqlite3'
    saved=rows(db,'SELECT record FROM news_classification_inputs')
    originals={}
    for row in saved:
        original=json.loads(row['record'])
        originals.setdefault(original['url'],[]).append(original)
    results=[];input_versions={}
    for day,run in [('2026-11-16','1b0e9a45d50343a2b946a9ecbecf36cb'),('2026-11-17','6f2765501976498dac21792f1e8fdea5')]:
        classified=[]
        requests=rows(ledger,"SELECT id,detail FROM requests WHERE run_id=? AND operation='model' AND status='success' ORDER BY rowid",(run,))
        for req in requests:
            body=read(P/'.workdata/ai_budget/openai/requests'/f"{req['id']}-request.json")['body']
            values=[json.loads(block) for block in re.findall(r'```json\s*([\s\S]*?)```',body['input']) if block.lstrip().startswith('[')]
            batch=next(value for value in values if value and isinstance(value[0],dict) and 'url' in value[0] and 'id' in value[0])
            response=read(Path(json.loads(req['detail'])['response_path']))
            text=''.join(part.get('text','') for item in response['output'] if item.get('type')=='message' for part in item.get('content',[]))
            selected=[]
            for record in batch:
                matches=[]
                for original in originals[record['url']]:
                    candidate=NewsItem.from_dict(deepcopy(original));candidate.id=str(record['id'])
                    with ai_task('news',background=True,report_date=day):
                        rendered=service._classification_payload([candidate],service._classify_text_limit())[0]
                    if all(rendered.get(k)==record.get(k) for k in ['id','title','url','source','published_at','date_audit','snippet','text']):
                        matches.append(candidate)
                assert matches, ('Saved original input does not match recorded prompt',record['url'])
                variants={json.dumps(asdict(it),sort_keys=True,ensure_ascii=False):it for it in matches}
                input_versions.setdefault(day,[]).append({'url':record['url'],'request_id':req['id'],
                    'recorded_input':record,'all_matching_saved_versions':[json.loads(v) for v in variants],
                    'view_policy':'All versions reproduce exact prompt fields including date audit; use longest preserved full-text view, not a claim of unique original document'})
                selected.append(max(variants.values(),key=lambda it:len(it.full_text or '')))
            with ai_task('news',background=True,report_date=day):
                classified.extend(service._apply_classification_meta(selected,_parse_ai_json_response(text)))
        assert len(requests)==10 and len(classified)==30
        repo=NewsRepository(REPLAY/(day+'-news.db'));repo.save_many(classified)
        assert all(repo.get_by_url(it.url).full_text==it.full_text for it in classified)
        save(day+'-news-replayed.json',[it.to_dict() for it in classified])
        results.append({'day':day,'recorded_classifier_responses':len(requests),'selected_classified':len(classified),
            'categories':dict(Counter(it.category for it in classified)),'excluded':sum('ai_excluded' in it.tags for it in classified),
            'local_fallback':sum('local_rule_fallback' in it.tags for it in classified),'bodies_preserved':True,
            'new_ai_calls':0})
    repo=NewsRepository(REPLAY/'news-1118.db')
    snapshots=rows(db,'SELECT * FROM news_discovery_sources WHERE run_id=?',('7dbc561d627e460c81b7fd402c90c8a9',))
    with sqlite3.connect(repo.db_path) as conn:
        for row in snapshots:
            conn.execute('INSERT INTO news_discovery_sources VALUES (?,?,?,?,?)',tuple(row[k] for k in ['run_id','record_sha256','url','record','saved_at']))
    events=[json.loads(line) for line in (P/'logs/scheduled_tasks/2026-11-18.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    recovered=repo.import_unclosed_refreshes(events,set(),as_of=datetime.fromisoformat('2026-11-19T08:00:00+08:00'),
        scheduled_run_ids=repo.scheduled_news_request_runs(ledger))
    assert len(recovered)==1 and repo.refresh_requires_resume()
    sources=repo.recent_discovery_sources(date(2026,11,18))
    with ai_task('news',background=True,report_date='2026-11-18'):
        service._checkpoint_news_sources(repo,sources)
        pending=repo.query_pending_classification(limit=0,as_of=date(2026,11,18))
        plan=service.news_workload_plan(len(pending),resume_saved=True)
    assert plan['skip_search'] and len(snapshots)==669 and pending
    unresolved=rows(ledger,"SELECT id,status,estimate,actual FROM requests WHERE run_id=? AND status!='success'",('7dbc561d627e460c81b7fd402c90c8a9',))
    assert len(unresolved)==1 and unresolved[0]['estimate']=='0.288884'
    with ai_task('news',background=True,report_date='2026-11-18'):
        examples={str(n):service.news_workload_plan(n) for n in [55,21,0]}
    save('news-original-versions.json',input_versions)
    save('news-replay.json',{'completed_days':results,'all_recorded_input_fields_and_date_audits_matched':True,
        'matching_versions_preserved':'news-original-versions.json','interrupted_1118':{'source_snapshots':len(snapshots),
        'merged_sources':len(sources),'eligible_saved_articles':len(pending),'recovered':recovered,'workload_plan':plan,
        'classification_not_rerun_without_saved_response':True,'unsettled_original_request_unchanged':unresolved},
        'workload_examples':examples,'new_paid_usd':'0'})
    print('News replay: 20 original classifier responses/60 items; Nov18 interrupted source run restored locally, no paid retry')


topic();news()
