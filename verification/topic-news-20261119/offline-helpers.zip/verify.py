from pathlib import Path
from contextlib import closing
import hashlib
import json
import sqlite3
import sys
from zipfile import ZipFile

W=Path(__file__).resolve().parents[3]
WORK=Path(__file__).resolve().parent
P=Path('D:/code/stock_ai_bot')
OUT=W/'verification/topic-news-20261119'
OUT.mkdir(parents=True,exist_ok=True)
assert Path(json.loads((WORK/'.codex-task.json').read_text())['project'])==W
sys.path.insert(0,str(W))


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    files=['main.py','README.md','config.json','config/secrets.json','config/research_center.json',
        'config/company_theme_map.json','config/theme_profiles.json','config/supply_chain_nodes.json','stock_list.json',
        'logs/topic_inputs/change_20261117_234022.json','logs/topic_ai_raw/change_20261117_234022.json',
        'data/topic/change_packs/change_20261117_234022.json']
    files += [p.relative_to(W).as_posix() for p in (W/'research_center').glob('*.py')]
    tables={}
    for name in ['.workdata/ai_budget/openai/openai-credits.sqlite3','.workdata/prod/database/stock_research.db',
                 '.workdata/prod/runtime/schedule_outcomes/outcomes.sqlite3']:
        with closing(sqlite3.connect((P/name).resolve().as_uri()+'?mode=ro',uri=True)) as c:
            c.execute('BEGIN')
            result={}
            for (table,) in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
                rows=c.execute('SELECT * FROM "'+table+'" ORDER BY rowid').fetchall()
                result[table]={'rows':len(rows),'sha256':hashlib.sha256(json.dumps(rows,ensure_ascii=False).encode()).hexdigest()}
            tables[name]=result
    return {'files':{name:sha(P/name) for name in files if (P/name).is_file()},'tables':tables}


mode=sys.argv.pop(1)
if mode in {'before','after'}:
    current=snapshot()
    if mode=='after':assert current==json.loads((OUT/'formal-before.json').read_text(encoding='utf-8'))
    (OUT/f'formal-{mode}.json').write_text(json.dumps(current,indent=2),encoding='utf-8')
    print('Production code/config/raw evidence and all accounting/news/outcome tables unchanged' if mode=='after' else 'Production snapshot captured readonly')
elif mode in {'restore','full'}:
    with ZipFile(W/'verification/ai-schedule-stability-20261107/live/offline-test-helpers.zip') as z:
        script=z.read('restore_fixtures.py' if mode=='restore' else 'full_suite.py').decode()
    script=script.replace('ROOT = Path(__file__).resolve().parents[3]',f'ROOT = Path({str(W)!r})')
    script=script.replace('ROOT=Path(__file__).resolve().parents[3]',f'ROOT=Path({str(W)!r})')
    script=script.replace("OUT = ROOT / 'verification/ai-schedule-stability-20261107/live'",f'OUT = Path({str(OUT)!r})')
    exec(compile(script,'archived-offline-helper.py','exec'),{'__file__':str(__file__)})
elif mode=='archive':
    import zipfile
    with ZipFile(OUT/'offline-helpers.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
        for name in ['verify.py','replay.py']:
            archive.write(WORK/name,name)
        with ZipFile(W/'verification/ai-schedule-stability-20261107/live/offline-test-helpers.zip') as original:
            for name in ['restore_fixtures.py','full_suite.py']:
                archive.writestr(name,original.read(name))
    with ZipFile(OUT/'rebuilt-unsent-prompts.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted((WORK/'prompts').glob('*.md')):archive.write(path,path.name)
    print('Replay/verification helpers and six unsent prompts archived outside owned temporary storage.')
else:
    raise ValueError(mode)
